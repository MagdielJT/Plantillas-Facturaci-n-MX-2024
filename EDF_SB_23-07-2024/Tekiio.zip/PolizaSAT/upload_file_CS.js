/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/ui/dialog'],
/**
 * @param{dialog} dialog
 */
function(dialog) {

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var currentRecord = scriptContext.currentRecord;

        var objFolder = currentRecord.getValue({
            fieldId: 'custpage_folder'
        });

        if(!objFolder || objFolder.length <= 0){
            dialog.alert({
                title: 'Folder Requerido',
                message: 'Por favor, asigne un valor en el parametro del scrip para definir la carpeta para contener los archivos.'
            });
            return false;
        }

        var objFile = currentRecord.getValue({
            fieldId: 'custpage_file'
        });

        if (!objFile){
            dialog.alert({
                title: 'Archivo Requerido',
                message: 'Por favor, elija un archivo para procesar.'
            });
            return false;
        }else {

            var arr = objFile.split('.');
            var ext = arr[arr.length-1];

            if(ext == 'xml'){
                return true;
            } else {
                dialog.alert({
                    title: 'Tipo de archivo no valido',
                    message: 'Elige un archivo válido (XML)'
                });

                return false;
            }
        }
    }

    return {
        saveRecord: saveRecord
    };
    
});
