/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
 define(['N/record'],
 function(record) {
     function beforeLoad(context) {
         var form = context.form;
        form.addButton({
            id : 'custpage_update',
            label : 'Actualizar',
            functionName: 'location.reload();'
        });
     }
     return {
         beforeLoad: beforeLoad
     };
 });