/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/ui/serverWidget','N/redirect','N/record','N/task','N/runtime'],
    /**
 * @param{serverWidget} serverWidget
 */
    (serverWidget, redirect,record,task,runtime) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            //let idFolder = 213541;
            let idFolder = runtime.getCurrentScript().getParameter({name: 'custscript_efx_directory_polizas_sat'});
            if (scriptContext.request.method === 'GET') {

                let formUpload = serverWidget.createForm({
                    title: 'Póliza SAT'
                });

                formUpload.clientScriptModulePath = './upload_file_CS';

                formUpload.addSubmitButton({
                    label: 'Procesar'
                });

                let field = formUpload.addField({
                    id: 'custpage_file',
                    type: 'file',
                    label: 'Archivo de Carga',

                });

                let fieldFolder = formUpload.addField({
                    id: 'custpage_folder',
                    type: 'text',
                    label: 'Carpeta de Carga'
                }).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
                fieldFolder.defaultValue = idFolder;

                scriptContext.response.writePage(formUpload);

            } else {
                let fileObj = scriptContext.request.files.custpage_file;

                fileObj.folder = idFolder;
                fileObj.name = fileObj.name.split('.')[0]+"_"+getSubDate()
                let idFile = fileObj.save();
                //let idFile = 1066758;

                if(idFile){
                    let idDetail = insertDetail(idFile);

                    var obj = {
                        idDetail: idDetail,
                        idFile: idFile,
                        idFolder: idFolder
                    };

                    var scriptTask = task.create({
                        taskType: task.TaskType.MAP_REDUCE,
                        scriptId: 'customscript_efx_upload_file_mr',
                        deploymentId: 'customdeploy_efx_upload_file_mr',
                        params: { 'custscript_efx_upload_poliza_sat_params': JSON.stringify(obj)}
                    });
                    scriptTask.submit();

                    redirect.toRecord({
                        type: 'customrecord_efx_poliza_sat',
                        id: idDetail,
                        isEditMode: false});
                }
            }
        }


        const insertDetail = (idFile) => {
            try{
                var history = record.create({
                    type: 'customrecord_efx_poliza_sat',
                    isDynamic: true
                });

                history.setValue({fieldId: 'custrecord_efx_archivo_cargado', value: idFile});
                history.setValue({fieldId: 'custrecord_efx_poliza_porcentaje', value: 0});

                return history.save();
            }catch (e) {
                log.error('Error','Error al crear registro de detalles: '+e.message);
                return null;
            }
        }

        const getSubDate = () => {
            let date_ob = new Date();
            let date = ("0" + date_ob.getDate()).slice(-2);
            let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
            let year = date_ob.getFullYear();
            let hours = date_ob.getHours();
            let minutes = date_ob.getMinutes();
            let seconds = date_ob.getSeconds();

            return year + month + date + "_" + hours + minutes + seconds;
        }



        return {onRequest}

    });
