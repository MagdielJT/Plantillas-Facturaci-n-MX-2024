/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
 define(['N/xml','N/file','N/search','N/record','N/runtime'],
 /**
  * @param{xml} xml
  * @param{file} file
  * @param{search} search
  * @param{record} record
  * @param{runtime} runtime
  */
 (xml, file, search,record,runtime) => {
     /**
      * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
      * @param {Object} inputContext
      * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {Object} inputContext.ObjectRef - Object that references the input data
      * @typedef {Object} ObjectRef
      * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
      * @property {string} ObjectRef.type - Type of the record instance that contains the input data
      * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
      * @since 2015.2
      */

     const getInputData = (inputContext) => {

         try{
             var obj = runtime.getCurrentScript().getParameter({name: 'custscript_efx_upload_poliza_sat_params'});
             var objjson = JSON.parse(obj);
             // log.audit({title: 'objjson', details: objjson});
             var idFile = objjson.idFile;
             var idDetail = objjson.idDetail;
             var idFolder = objjson.idFolder;

             let fileXML = file.load({
                 id : idFile
             });

             var xmlFileContent = fileXML.getContents();
             var xmlDocument = xml.Parser.fromString({
                 text: xmlFileContent
             });

             var numChanges = processFile(xmlDocument, idDetail);

             if(numChanges && numChanges > 0){
                var nweliNodo = eliUUIDNodo(xmlDocument);
                // var actNodo = updateTransfer(xmlDocument);
                 var newFile = file.create({
                     name : fileXML.name.split('.')[0] + '_updated_'+getSubDate(),
                     fileType : file.Type.XMLDOC,
                     contents : xml.Parser.toString({
                         document : xmlDocument
                     }),
                     folder : idFolder
                 });

                 var idNewFile = newFile.save();
                 updateDetail(idDetail, idNewFile, null);

             } else {
                 updateDetail(idDetail, null, "NO SE ACTUALIZÓ NINGUNA PÓLIZA");
             }

         }catch(ex){
             log.error({ title: 'getInputData: error searching record', details: ex });
             return [];
         }

     }

     const eliUUIDNodo = (xmlDocument) =>{
         try {
             var polizaNode = xml.XPath.select({
                 node: xmlDocument,
                 xpath: '//PLZ:Poliza'
             });
             for(var p = 0; p < polizaNode.length; p++) {
                let tranNodes_validate = polizaNode[p].getElementsByTagName({
                    tagName: 'PLZ:OtrMetodoPago'
                });
                if (tranNodes_validate.length != 0) {
                    for (var t = 0; t < tranNodes_validate.length; t++) {
                        let  tranNode_validate = tranNodes_validate[t];

                        if (tranNode_validate.hasAttributes()) {
                            let uuid_validate = tranNode_validate.getAttribute({
                                name: "UUID_CFDI"
                            }).trim();
                            if (uuid_validate) {
                                tranNode_validate.removeAttribute({
                                    name: "UUID_CFDI"
                                });
                            }
                        }
                    }
                }
             }
             return "1";
         } catch (e) {
             log.error({title: "eliUUIDNodo Error", details: e});
         }
     }

     const updateTransfer = (xmlDocument) =>{
        try {
            var polizaNode = xml.XPath.select({
                node: xmlDocument,
                xpath: '//PLZ:Poliza'
            });
            for(var p = 0; p < polizaNode.length; p++) {

               let tranNodes_validate = polizaNode[p].getElementsByTagName({
                   tagName: 'PLZ:Transferencia'
               });

               var datePoliza = polizaNode[p].getAttribute({
                    name: "Fecha"
                });
                var concPoliza = polizaNode[p].getAttribute({
                    name: "Concepto"
                });
                var idPoliza = polizaNode[p].getAttribute({
                    name: "NumUnIdenPol"
                });

               if (tranNodes_validate.length != 0) {
                   for (var t = 0; t < tranNodes_validate.length; t++) {
                       let  tranNode_validate = tranNodes_validate[t];

                       if (tranNode_validate.hasAttributes()) {
                           let bancDest_validate = tranNode_validate.getAttribute({
                               name: "BancoDestNal"
                           }).trim();
                           if (bancDest_validate == "") {                               

                               log.debug({
                                   title: "Banco",
                                   details: "La transferencia no tiene BancoDestNal"
                               });
                               log.debug({
                                   title: "ID, Fecha y concepto",
                                   details: idPoliza + " - " + datePoliza + " - " + concPoliza
                               });
                               searchBanc(datePoliza, concPoliza,idPoliza);
                           }
                       }
                   }
               }
            }
            return "1";
        } catch (e) {
            log.error({title: "updateTransfer Error", details: e});
        }
    }

    const searchBanc = (date, concep, idpoliza) =>{
        if (idpoliza.startsWith("Pago de factura")) {
            var tiposearch = "VendPymt";

        } else {
            var tiposearch = "CustPymt";
        }
        var newDate = remDate(date);
        // log.debug("Nuevo Valor Date", newDate);
        var tranSearch = search.create({
            type: search.Type.TRANSACTION,
            filters: 
                [
                    ["type", "anyof", tiposearch],
                    "AND",
                    ["trandate","on",newDate],
                    "AND",
                    ["memo", "contains", "TRF. F-MEMFC718248 CENACE *SERVICIOS ELECTRICOS"]
                ],
            columns: [
                search.createColumn({name: "custbody_mx_bank_information", label: "Información del banco"})
            ]
        });
        var searchBancRun = tranSearch.runPaged().count;
        log.debug({title: "searchBank", details: searchBancRun});
    }

    const remDate = (date) =>{
        var arraydate = date.split("-");
        var newdate = "";
        for (var i = 0; i < arraydate.length; i++) {
            // log.debug("ArrayDate " + i, arraydate[i]);
            if (i<arraydate.length-1) {
                newdate += arraydate[i] + "/";
            }
        }
        return newdate;
    }

     /**
      * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
      * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
      * context.
      * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
      *     is provided automatically based on the results of the getInputData stage.
      * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
      *     function on the current key-value pair
      * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
      *     pair
      * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {string} mapContext.key - Key to be processed during the map stage
      * @param {string} mapContext.value - Value to be processed during the map stage
      * @since 2015.2
      */

     const map = (mapContext) => {

     }

     /**
      * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
      * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
      * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
      *     provided automatically based on the results of the map stage.
      * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
      *     reduce function on the current group
      * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
      * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {string} reduceContext.key - Key to be processed during the reduce stage
      * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
      *     for processing
      * @since 2015.2
      */
     const reduce = (reduceContext) => {

     }


     /**
      * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
      * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
      * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
      * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
      *     script
      * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
      * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
      * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
      * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
      *     script
      * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
      * @param {Object} summaryContext.inputSummary - Statistics about the input stage
      * @param {Object} summaryContext.mapSummary - Statistics about the map stage
      * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
      * @since 2015.2
      */
     const summarize = (summaryContext) => {

     }

     const updateDetail = (idDetail, idNewFile, error) => {
         try{
             var history = record.load({
                 type: 'customrecord_efx_poliza_sat',
                 id: idDetail,
                 isDynamic: true
             });

             history.setValue({fieldId: 'custrecord_efx_archivo_modificado', value: idNewFile});
             history.setValue({fieldId: 'custrecord_efx_poliza_porcentaje', value: 100});

             if(error){
                 var errors = error+ '\n\r' + history.getValue({fieldId: 'custrecord_efx_poliza_error'});
                 history.setValue({fieldId: 'custrecord_efx_poliza_error', value: errors});
             }

             return history.save();
         }catch (e) {
             log.error('Error','Error al crear registro de detalles: '+e.message);
             return null;
         }
     }


     const processFile = (xmlDocument, idDetail) => {
         try{
             var numProcess = 0;
             var polizaNode = xml.XPath.select({
                 node: xmlDocument,
                 xpath: '//PLZ:Poliza'
             });

             for(var p = 0; p < polizaNode.length; p++) {//Recorre Poliza
                 try{
                     var resPoliza = {
                         NumUnIdenPol: "",
                         uuid: ""
                     };
                     var numPoliza = polizaNode[p].getAttribute({
                         name: "NumUnIdenPol"
                     });

                     if(numPoliza && numPoliza.startsWith("Diario")){//Es Diario??
                         var arrNumPoliza = numPoliza.split(' ');
                         resPoliza.NumUnIdenPol = arrNumPoliza[1];
                         var tranNodes = polizaNode[p].getElementsByTagName({
                             tagName: 'PLZ:Transaccion'
                         });

                         for (var t = 0; t < tranNodes.length; t++) { //Recorre transaccion
                             var tranNode = tranNodes[t];
                             if (tranNode.hasChildNodes()) { //Tiene hijos la transacción
                                 var compNalNodes = tranNode.getElementsByTagName({
                                     tagName: 'PLZ:CompNal'
                                 });
                                 if (compNalNodes[0].hasAttributes()) { //Tiene atributos CompNal
                                     resPoliza.uuid = compNalNodes[0].getAttribute({
                                         name: "UUID_CFDI"
                                     }).trim();
                                     var rfc = compNalNodes[0].getAttribute({
                                         name: "RFC"
                                     });

                                     //log.audit({title: 'resPoliza data', details: {uuid: resPoliza.uuid, rfc: rfc, validacion: (rfc.length && resPoliza.uuid.length)}});
                                     if (resPoliza.uuid.length > 0) {
                                         if (rfc.length == 0) { //Tiene RFC
                                             if (resPoliza.uuid.length > 0 && resPoliza.NumUnIdenPol.length > 0) {
                                                 var newRFC = searchRFC(resPoliza);
                                                 if (newRFC && newRFC.length > 0) {
                                                     var rfc = newRFC[0].getValue(newRFC[0].columns[0]);

                                                     if (rfc.trim().length > 0) {
                                                         log.debug({
                                                             "title": "RFC recuperado",
                                                             "details": rfc
                                                         });
                                                         compNalNodes[0].removeAttribute({
                                                             name: "RFC"
                                                         });

                                                         compNalNodes[0].setAttribute({
                                                             name: "RFC",
                                                             value: newRFC[0].getValue(newRFC[0].columns[0])
                                                         });

                                                         numProcess++;
                                                     } else {
                                                         var error = "UUID:" + resPoliza.uuid + ", Numero de póliza: " + resPoliza.NumUnIdenPol + ": RFC no capturado";
                                                         updateDetail(idDetail, null, error);
                                                     }
                                                 } else {
                                                     var error = "UUID:" + resPoliza.uuid + ", Numero de póliza: " + resPoliza.NumUnIdenPol + ": RFC no encontrado";
                                                     updateDetail(idDetail, null, error);
                                                 }
                                             } else {
                                                 var error = "UUID:" + resPoliza.uuid + " o Numero de póliza: " + resPoliza.NumUnIdenPol + " incorrecto";
                                                 updateDetail(idDetail, null, error);
                                             }
                                         }//Tiene RFC
                                     } else {
                                         // log.audit({title: 'Poliza a eliminar', details:{msj: "No contiene UUID la póliza: " + numPoliza, node: polizaNode[p]}});
                                         /*var error = "No contiene UUID la póliza: " + resPoliza.NumUnIdenPol;
                                         updateDetail(idDetail, null, error);*/
                                         tranNode.removeChild({
                                             oldChild: compNalNodes[0]
                                         });
                                     }
                                 }//Tiene atributos CompNal
                             }//Tiene hijos la transacción
                         }//Recorre transaccion
                     } //Es Diario
                     else {
                         /**
                          * Validación de existencia de uuid en transacciones
                          */
                         let tranNodes_validate = polizaNode[p].getElementsByTagName({
                             tagName: 'PLZ:Transaccion'
                         });

                         for (let t = 0; t < tranNodes_validate.length; t++) { //Recorre transaccion
                             let  tranNode_validate = tranNodes_validate[t];
                             if (tranNode_validate.hasChildNodes()) { //Tiene hijos la transacción
                                 let  compNalNodes_validate = tranNode_validate.getElementsByTagName({
                                     tagName: 'PLZ:CompNal'
                                 });
                                 if (compNalNodes_validate[0].hasAttributes()) { //Tiene atributos CompNal
                                     let uuid_validate = compNalNodes_validate[0].getAttribute({
                                         name: "UUID_CFDI"
                                     }).trim();
                                     let rfc_validate = compNalNodes_validate[0].getAttribute({
                                         name: "RFC"
                                     });

                                     if (!uuid_validate.length /*&& !rfc_validate.length*/) {
                                         log.audit({title: 'Poliza a eliminar', details:{msj: "No contiene UUID la póliza: " +numPoliza}});
                                         let error = "No contiene UUID la póliza: " + numPoliza;
                                         updateDetail(idDetail, null, error);
                                         tranNode_validate.removeChild({
                                             oldChild: compNalNodes_validate[0]
                                         });
                                     }
                                 }
                             }
                         }
                     }
                 }catch (e) {
                     log.error('Error','Error al leer el archivo XML FOR: '+e.message);
                     //return null;
                 }
             }//Recorre Poliza

             return numProcess;

         }catch (e) {
             log.error('Error','Error al leer el archivo XML: '+e.message);
             return null;
         }
     }

     const searchRFC = (resPoliza) => {
         try{

             log.debug({
                 "title" : "Datos a buscar",
                 "details" : resPoliza
             });
             var journalentrySearchObj = search.create({
                 type: "journalentry",
                 filters:
                     [
                         ["custbody_mx_cfdi_uuid","is",resPoliza.uuid],
                         "AND",
                         ["glnumber","is",resPoliza.NumUnIdenPol],
                         "AND",
                         ["type","anyof","Journal"]
                     ],
                 columns:
                     [
                         search.createColumn({
                             name: "entity",
                             label: "nombre"})
                     ]
             });
             var searchResultCount = journalentrySearchObj.runPaged().count;
             log.debug("journalentrySearchObj result count",searchResultCount);
             var journals = journalentrySearchObj.run().getRange(0, 1);
             log.debug({
                 title: "Journals",
                 details: journals
             })

             if(searchResultCount > 0){
                 var rfcSearch = search.create({
                     type: "employee",
                     filters:
                         [
                             ["internalid","anyof",journals[0].getValue(journals[0].columns[0])]
                         ],
                     columns:
                         [
                             search.createColumn({
                                 name: "custentity_mx_rfc",
                                 label: "RFC"})
                         ]
                 });
                 var searchRFCCount = rfcSearch.runPaged().count;
                 log.debug("rfcSearch result count",searchRFCCount);

                 if(searchRFCCount == 0){
                     var rfcSearchVendor = search.create({
                         type: search.Type.VENDOR,
                         filters:
                             [
                                 ["internalid","anyof",journals[0].getValue(journals[0].columns[0])]
                             ],
                         columns:
                             [
                                 search.createColumn({
                                     name: "custentity_mx_rfc",
                                     label: "RFC"})
                             ]
                     });

                     var searchRFCVendorCount = rfcSearchVendor.runPaged().count;
                     log.debug("rfcSearch result count (vendor)",searchRFCVendorCount);
                     return rfcSearchVendor.run().getRange(0, 1);
                 } else {
                     return rfcSearch.run().getRange(0, 1);
                 }
             }

         }catch(ex){
             log.error({ title: 'getInputData: error searching record', details: ex });
             return [];
         }
     }

     const getSubDate = () => {
         let date_ob = new Date();
         let date = ("0" + date_ob.getDate()).slice(-2);
         let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
         let year = date_ob.getFullYear();
         let hours = date_ob.getHours();
         let minutes = date_ob.getMinutes();
         let seconds = date_ob.getSeconds();

         return year + month + date + "_" + hours + minutes + seconds;
     }

     return {getInputData, map, reduce, summarize}

 });
