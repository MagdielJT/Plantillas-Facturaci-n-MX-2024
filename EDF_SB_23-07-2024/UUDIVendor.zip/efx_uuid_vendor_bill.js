/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord','N/log', 'N/url', 'N/https', 'N/search', 'N/ui/message'],

function(currentRecord,log, url, https, search, msg) {


    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        try{
            // var casilla = currentRecord.get().getValue('custbodyefx_casillaveruo');
            // if(casilla == 'T'){
            //     log.debug('hacer proceso')
            // }
            switch (scriptContext.fieldId) {

                case 'custbody_efx_uid_ip_pdf':

                    log.debug({title:'FC',details:'Se ejecuto el campo de PDF'});
                    return validate(1);
                    break;

                case 'custbody_efx_uuid_ip_xml':

                    log.debug({title:'FC',details:'Se ejecuto el campo de XML'});
                    return validate(2);
                    break;


                default:
                    break;

            }

        }
        catch(e){
            log.error({title:'fieldschangeerror',details:e});

        }
    }

    function validate( option ) { //Validate

        try{
            var billcurrent=currentRecord.get();
            if (option == 1) {
                var value = billcurrent.getValue({fieldId: 'custbody_efx_uid_ip_pdf'}); //Obtener ID de documento cargado
            }
            else {
                var value = billcurrent.getValue({fieldId: 'custbody_efx_uuid_ip_xml'});
            }
            var vendorID = currentRecord.get().getValue('entity');

            log.debug({title:'IDvalue',details:option});

            var output = url.resolveScript({                                //URL suitlet, ubicacion
                scriptId: 'customscript_efx_uid_invoice_provider_sl',
                deploymentId: 'customdeploy_efx_uid_invoice_provider_sl',
                params: {fid:value, n:option, dlt: false},
                returnExternalUrl: false
            });
            log.debug({title:'output',details:output});

            var urlsl = window.location.origin+output;                            //URL suitlet, dominio

            var response = https.get({url: urlsl});                               //Response suitlet
            log.debug({title:'response',details:response});

            var jsans = JSON.parse(response.body);

            var rfcv = RFCvendor();
            log.debug({title:'rfc',details:rfcv});

            if (jsans.success == true && option ==  2 && rfcv.custentity_mx_rfc != jsans.rfc){

                jsans['success'] = false
                jsans['msg'] = 'El RFC del documento XML no coincide con el del proveedor, revisar el documento.'

            }
            else if(jsans.success == true && option ==  2 && rfcv.custentity_mx_rfc == jsans.rfc){
                billcurrent.setValue({fieldId: 'custbody_mx_cfdi_uuid', value: jsans.uuid});
                billcurrent.setValue({fieldId: 'custbody_mx_customer_rfc', value: jsans.rfc});
            }
            log.debug({title:'success',details:jsans.success});
            if (jsans.success == false) {

                var c = showMessage(jsans.msg);
                window.scroll(0,0)

                if (option == 1)
                    billcurrent.setValue({fieldId: 'custbody_efx_uid_ip_pdf', value: 0})
                else
                    billcurrent.setValue({fieldId: 'custbody_efx_uuid_ip_xml', value: 0})
            }
            // if (c == true) {
            //     // output = url.resolveScript({                                //URL suitlet, ubicacion
            //     //     scriptId: 'customscript_efx_uid_invoice_provider_sl',
            //     //     deploymentId: 'customdeploy_efx_uid_invoice_provider_sl',
            //     //     params: {fid: value, n: option, dlt: false},
            //     //     returnExternalUrl: false
            //     // });
            //     // urlsl = window.location.origin+output;
            //     // response = https.get({url: urlsl});
            //     // jsans = JSON.parse(response.body);
            //     // if (jsans.success == true)
            //         // alert (jsans.msg)
            // }


            return true;
        }
        catch(e){
            log.error({title:'validate',details:e});
        }

    }

    function showMessage(message) {
        try{
            msg.create({
                title: "Error al subir archivo",
                message: message, //'Please Approve',
                type: msg.Type.ERROR
            }).show({
                duration: 10000
            });
        }catch (e) {
            log.error('Error in showMessage', e)
        }
    }

    function RFCvendor(){
        try {
            var billcurrent = currentRecord.get();
            var vendorid = billcurrent.getValue({fieldId: 'entity'});
            var vendorrfc = search.lookupFields({
                type: search.Type.VENDOR,
                id: vendorid,
                columns: ['custentity_mx_rfc']
            });
            return vendorrfc;
        }
        catch (e) {
            log.error('Error in RFCVendr', e)
        }
    }

    return {
        fieldChanged: fieldChanged,
    };
    
});
