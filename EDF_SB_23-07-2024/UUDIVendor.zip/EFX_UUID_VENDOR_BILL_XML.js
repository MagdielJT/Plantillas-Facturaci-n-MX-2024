/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/file','N/xml'],
/**
 * @param{file} file
 */
function(file, xml) {
   
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} context
     * @param {ServerRequest} context.request - Encapsulation of the incoming request
     * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
     * @Since 2015.2
     */
    //file.delete(id)
    function onRequest(context) {

        try {
            log.debug('Entro', context.request)
            var params = context.request.parameters;

            if (params) {

                var F = file.load({id: params.fid});
                var n = 0;
                var jsmsg = {success: false, rfc: '', uuid: '', msg: 'Favor de validar su documento.'}

                if (params.dlt == 'false') {

                    if (F) {

                        if (F.fileType == 'PDF') {

                            n = 1

                        } else if (F.fileType == 'XMLDOC') {

                            n = 2

                        } else {
                            context.response.write({output: JSON.stringify(jsmsg)});
                            return true;
                        }

                    }
                    if (n == params.n) {
                        jsmsg['success'] = true;
                        jsmsg['msg'] = '';
                        if (n == 2) {
                            try {
                                var xmlF = xml.Parser.fromString({text: F.getContents()});
                                var FNode;
                                FNode = xml.XPath.select({node: xmlF, xpath: '//cfdi:Emisor'});
                                jsmsg['rfc'] = FNode[0].getAttribute({name: 'Rfc'});
                                FNode = xml.XPath.select({node: xmlF, xpath: '//tfd:TimbreFiscalDigital'});
                                jsmsg['uuid'] = FNode[0].getAttribute({name: 'UUID'});
                            } catch (e) {
                                jsmsg['success'] = false;
                                jsmsg['msg'] = 'XML Inválido';
                                context.response.write({output: JSON.stringify(jsmsg)});
                                return true;
                            }
                        }
                        context.response.write({output: JSON.stringify(jsmsg)});
                    } else {
                        context.response.write({output: JSON.stringify(jsmsg)});
                        return true;
                    }
                }
                else if (params.dlt == 'true') {
                    file.delete({id: params.fid})
                    jsmsg = {success: true, rfc: '', uuid: '', msg: 'Documento Eliminado'}
                    context.response.write({output: JSON.stringify(jsmsg)});
                }
            }
            return true;
        }
        catch(e){
            return true;
        }
    }

    return {
        onRequest: onRequest
    };
    
});
