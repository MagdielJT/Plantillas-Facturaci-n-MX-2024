/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/format', 'N/log', 'N/record', 'N/search','N/runtime'],

    (format, log, record, search,runtime) => {

            const notaDebitoTemplate=146
            const invoiceTemplate=154
            const beforeLoad = (scriptContext) => {

            }



            const beforeSubmit = (scriptContext) => {
                    try{
                            if (scriptContext.type === scriptContext.UserEventType.EDIT || scriptContext.type === scriptContext.UserEventType.CREATE)
                            {
                                    var objRecord = scriptContext.newRecord;
                                    if(objRecord.type === record.Type.CUSTOMER_PAYMENT)
                                    {
                                            var id_pago = objRecord.id;
                                            log.audit('id_pago',id_pago)
                                            var numLine = objRecord.getLineCount({sublistId: 'apply'});
                                            log.audit('numLine',numLine)
                                            var numLine = objRecord.getLineCount({sublistId: 'apply'});
                                            var lineApply = null;
                                            var facturasRevisionStatus=[]
                                            for (var j = 0; j < numLine; j++)
                                            {
                                                var applyPaymet = objRecord.getSublistValue({
                                                    sublistId: 'apply',
                                                    fieldId: 'internalid',
                                                    line: j
                                                });
                                                var applyPaymetFlag = objRecord.getSublistValue({
                                                    sublistId: 'apply',
                                                    fieldId: 'apply',
                                                    line: j
                                                });

                                                var paymetCreatedFrom = objRecord.getSublistValue({
                                                    sublistId: 'apply',
                                                    fieldId: 'createdfrom',
                                                    line: j
                                                });
                                                var id_aplicacion_pago = applyPaymet.toString() * 1
                                                var id_origen_pago = paymetCreatedFrom.toString() * 1
                                                var aplicacionesPago={
                                                    applyPaymet:id_aplicacion_pago,
                                                    applyPaymetFlag:applyPaymetFlag,
                                                    paymetCreatedFrom:id_origen_pago
                                                }
                                                if(aplicacionesPago.applyPaymetFlag)    //si ese pago esta afectando mas transacciones solamente carga los que tenga la bandera de aplicado
                                                {
                                                    facturasRevisionStatus.push(aplicacionesPago)
                                                }
                                            }
                                            //log.audit("facturasRevisionStatus",facturasRevisionStatus)


                                            if(facturasRevisionStatus.length==1){
                                                var countFacturasRevision=facturasRevisionStatus.length;
                                                var variableDatosFactura=[]
                                                for(var w=0;w<countFacturasRevision;w++){
                                                    var idFacturaOrigen=facturasRevisionStatus[w].applyPaymet;
                                                    var invoiceObj = record.load({
                                                        type: record.Type.INVOICE,
                                                        id: idFacturaOrigen
                                                    });
                                                    var serieFacturaOrigen = invoiceObj.getValue({fieldId: 'custbody_tko_serie'});
                                                    var folioFacturaOrigen = invoiceObj.getValue({fieldId: 'custbody_tko_folio'});

                                                    var fusion_sere_folio=serieFacturaOrigen+""+folioFacturaOrigen
                                                        log.audit("serieFolio",serieFacturaOrigen+""+folioFacturaOrigen)
                                                    variableDatosFactura.push({
                                                        seriefoliodata:fusion_sere_folio
                                                    })
                                                }
                                                log.audit("variableDatosFactura",variableDatosFactura)
                                            }else{
                                                log.audit("IMPORTANTE","Hay mas de una factura ligada a este pago")
                                            }


                                            objRecord.setValue({
                                                     fieldId: 'custbody_tkio_invoice_data',
                                                     value: JSON.stringify(variableDatosFactura)
                                             });

                                            //var formularioPersonalizado = objRecord.getValue({fieldId: 'customform'})*1;
                                            //
                                            // var formularioPersonalizado = objRecord.getValue({fieldId: 'customform'})*1;
                                            // var id_form_nota_debito = runtime.getCurrentScript().getParameter({name: 'custscript_tkio_form_nd'})*1;
                                            // var id_form_factura = runtime.getCurrentScript().getParameter({name: 'custscript_tkio_form_invoice'})*1;
                                            //
                                            // log.audit('id_form_nota_debito',id_form_nota_debito)
                                            // log.audit('id_form_factura',id_form_factura)
                                            //
                                            // var plantillaUsar=''
                                            // switch (formularioPersonalizado) {
                                            //         case id_form_nota_debito:
                                            //                 plantillaUsar="NOTA_DEBITO"
                                            //                 break;
                                            //         case id_form_factura:
                                            //                 plantillaUsar="FACTURA"
                                            //                 break;
                                            // }
                                            //
                                            // log.audit('plantillaUsar',plantillaUsar)
                                            //
                                            // objRecord.setValue({
                                            //         fieldId: 'custbody_efx_tkio_form_selected',
                                            //         value: plantillaUsar
                                            // });
                                    }
                            }
                    }catch (e) {
                            log.error({title: 'Error on beforeSubmit', details: e});
                    }
            }

            /**
             * Defines the function definition that is executed after record is submitted.
             * @param {Object} scriptContext
             * @param {Record} scriptContext.newRecord - New record
             * @param {Record} scriptContext.oldRecord - Old record
             * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
             * @since 2015.2
             */
            const afterSubmit = (scriptContext) => {

            }

            return {beforeLoad, beforeSubmit, afterSubmit}

    });
