/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/format', 'N/log', 'N/record', 'N/search','N/runtime'],
    
    (format, log, record, search,runtime) => {

        const notaDebitoTemplate=146
        const invoiceTemplate=154
        const beforeLoad = (scriptContext) => {

        }



        const beforeSubmit = (scriptContext) => {
                try{
                        if (scriptContext.type === scriptContext.UserEventType.EDIT || scriptContext.type === scriptContext.UserEventType.CREATE)
                        {
                                var objRecord = scriptContext.newRecord;
                                if(objRecord.type === record.Type.INVOICE)
                                {
                                        var formularioPersonalizado = objRecord.getValue({fieldId: 'customform'})*1;
                                        var id_form_nota_debito = runtime.getCurrentScript().getParameter({name: 'custscript_tkio_form_nd'})*1;
                                        var id_form_factura = runtime.getCurrentScript().getParameter({name: 'custscript_tkio_form_invoice'})*1;

                                        log.audit('id_form_nota_debito',id_form_nota_debito)
                                        log.audit('id_form_factura',id_form_factura)

                                        var plantillaUsar=''
                                        switch (formularioPersonalizado) {
                                                case id_form_nota_debito:
                                                        plantillaUsar="NOTA_DEBITO"
                                                        break;
                                                case id_form_factura:
                                                        plantillaUsar="FACTURA"
                                                        break;
                                        }

                                        log.audit('plantillaUsar',plantillaUsar)

                                        objRecord.setValue({
                                                fieldId: 'custbody_efx_tkio_form_selected',
                                                value: plantillaUsar
                                        });
                                }
                        }
                }catch (e) {
                        log.error({title: 'Error on beforeSubmit', details: e});
                }
        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });
