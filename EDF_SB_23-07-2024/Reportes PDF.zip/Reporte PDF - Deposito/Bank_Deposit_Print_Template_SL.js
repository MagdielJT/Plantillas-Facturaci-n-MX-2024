/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
define(["N/search", "N/ui/serverWidget", "N/record", "N/log", "N/format", "N/format/i18n", "N/render", "N/url", "N/file"],
    function (search, serverWidget, record, log, format, i18n, render, url, file) {

        var glbForm;
        var glbRecId;
        var glbCurRecord;
        var glbSublistId;
        var glbSublistId_nameMonto;

        var glbPdfData = {};

        function onRequest(context) {
            try {

                glbForm = serverWidget.createForm({
                    title: 'Impresión de Depósito '
                });

                // log.audit({
                //     title: 'Parámetros',
                //     details: context.request.parameters
                // });

                if (context.request.parameters.recId) {

                    glbRecId = context.request.parameters.recId;

                    glbCurRecord = record.load({
                        type: 'deposit',
                        id: glbRecId,
                        isDynamic: true
                    });

                    var existPayment = false;

                    existPayment = getPayment();

                    glbSublistId = (existPayment) ? 'payment' : 'other';
                    glbSublistId_nameMonto = (existPayment) ? 'transactionamount' : 'amount';

                    log.error({
                        title: 'glbSublistId',
                        details: glbSublistId
                    });

                    // Datos de customer

                    var entity = glbCurRecord.getSublistValue({
                        sublistId: glbSublistId,
                        fieldId: 'entity',
                        line: 0
                    });




                    var recEmployee = getEmployee(entity); // Record de customer




                    var direc=recEmployee.values.getValue({
                        fieldId: 'address'

                    });




                    var currency = glbCurRecord.getValue({
                        fieldId: 'currency'
                    });

                    var subsidiary = glbCurRecord.getValue({
                        fieldId: 'subsidiary'
                    });

                    var recSubsidiary = getSubsidiary(subsidiary);

                    var subLogo = recSubsidiary.values.getValue({
                        fieldId: 'logo'
                    });





                    var lookUp = search.lookupFields({
                        type: search.Type.CURRENCY,
                        id: currency,
                        columns: ['symbol']
                    });

                    glbPdfData['data'] = {
                        folio: glbCurRecord.getValue({
                            fieldId: 'id'
                        }),
                        fecha: formatDate(glbCurRecord.getValue({
                            fieldId: 'trandate'
                        })),
                        empresaRecibe: glbCurRecord.getSublistText({
                            sublistId: glbSublistId,
                            fieldId: 'entity',
                            line: 0
                        }),

                        direc: recEmployee.values.getValue({fieldId: 'defaultaddress'}) || 'Sin dirección',
                        empresa: glbCurRecord.getText({fieldId: 'subsidiary'}).toString().replace("&", "&amp;"),
                        depositante: glbCurRecord.getText({
                            fieldId: 'account'
                        }),
                        bancodep: glbCurRecord.getValue({
                            fieldId: 'custbody_tko_banco_beneficiario'
                        }),
                        cuentadep: glbCurRecord.getValue({
                            fieldId: 'custbody_tko_cuenta_beneficiario'
                        }),
                        bancoretiro: glbCurRecord.getValue({
                            fieldId: 'custbody_tko_banco_retiro'
                        }),
                        cuentaretiro: glbCurRecord.getValue({
                            fieldId: 'custbody_tko_cuentaretiro'
                        }),
                        nota: glbCurRecord.getValue({
                            fieldId: 'memo'
                        }),
                        direccion: glbCurRecord.getValue({
                            fieldId: 'custbody_tko_direccion_subsidiaria'
                        }),
                        importe: glbCurRecord.getValue({
                            fieldId: 'total'
                        }),


                        banco: '',
                        cuenta: glbCurRecord.getSublistValue({
                            sublistId: glbSublistId,
                            fieldId: 'account_display',
                            line: 0
                        }),
                        concepto: glbCurRecord.getSublistValue({
                            sublistId: glbSublistId,
                            fieldId: 'memo',
                            line: 0
                        }),
                        monto: glbCurRecord.getSublistValue({
                            sublistId: glbSublistId,
                            fieldId: glbSublistId_nameMonto,
                            line: 0
                        }),
                        montoLetra: '',
                        tituloFormato: 'Formato de Depósito',
                        logo: getImageURL(subLogo),



                    };
                    log.audit({title: 'direccion arriba ', details: direc});
                    log.audit({title: 'glbPdfData.data.monto', details: glbPdfData.data.monto});
                    log.audit({title: 'lookUp.symbol', details: lookUp.symbol});

                    glbPdfData.data.montoLetra = getMontoLetra(glbPdfData.data.monto, lookUp.symbol).toUpperCase();

                    glbPdfData.banco = '';

                    var templateFile = renderizarPDF();

                    context.response.writeFile({
                        file: templateFile,
                        isInline: true
                    });

                } else {
                    log.error({
                        title: 'onRequest - error',
                        details: 'No se recibió ID del depósito'
                    });
                }

            } catch (e) {
                log.error({
                    title: 'onRequest - error',
                    details: JSON.stringify(e)
                });
            }
        }

        function getPayment() {
            var subListId = 'payment';

            try {

                subListId = glbCurRecord.getSublistValue({
                    sublistId: 'payment',
                    fieldId: 'deposit',
                    line: 0
                });

                if (subListId) {
                    return true;
                }

            } catch (e) {
                log.error({
                    title: 'getPayment',
                    details: e
                });

                return false;
            }
        }

        function getEmployee(recId) {

            var recEmployee = null;
            var tipo = '';



            var consulta = search.create({
                type: search.Type.ENTITY,
                columns: ['type','address'],
                filters: ['internalid', 'is', recId]
            });

            consulta.run().each(function(result){

                tipo=result.recordType;
                log.audit({title: 'result', details: tipo});

                var direccionPrueba = result.getValue({
                    name: 'address'
                });
                log.audit({title: 'direccion busqueda', details: direccionPrueba});


                return true;

            });

            recEmployee = record.load({
                type: tipo,
                id: recId,
                isDynamic: true
            });


            return {result: true, values: recEmployee};


        }
        function getSubsidiary(recId) {
            var recSubsidiary = record.load({
                type: 'subsidiary',
                id: recId,
                isDynamic: true
            });

            return {result: true, values: recSubsidiary};
        }

        function getImageURL(imageId) {
            try {
                var remplaceUrl = '';
                if(imageId){
                    var logoFile = file.load({
                        id: imageId
                    });

                    var logoURL = logoFile.url;
                    var scheme = 'https://';
                    var host = url.resolveDomain({
                        hostType: url.HostType.APPLICATION
                    });

                    var urlFinal = scheme + host + logoURL;
                    log.audit({title: 'urlFinal', details: urlFinal});

                    remplaceUrl = urlFinal.toString().replace("&", "&amp;");
                    log.audit({title: 'urlFinal replace &', details: remplaceUrl});
                }else{
                    remplaceUrl='';
                }
                return remplaceUrl;
            } catch (e) {
                log.error({
                    title: 'Error getImageURL',
                    details: e
                })
                return remplaceUrl;
            }
        }


        function getMontoLetra(dato, symbol) {


            var spellOut = i18n.spellOut({
                number: dato,
                locale: "ES"
            });

            var monto = dato.toString().split('.');

            if (monto[1] == undefined) {
                monto[1] = "00";
            }
            var traduccionMonedaLetra=""
            switch (symbol) {
                case "MXN":
                    symbol = "MN";
                    traduccionMonedaLetra="PESOS"
                    break;
                case "USD":
                    symbol = "USD";
                    traduccionMonedaLetra="DÓLARES"
                    break;
            }
            // if (symbol == 'MXN') {
            //     symbol = "MN";
            // }

            var texto = spellOut.split(" coma");
            var traduccion = texto[0] + " "+traduccionMonedaLetra+" " + monto[1] + "/100 " + symbol;
            log.audit({title: 'letra:', details: traduccion});

            return traduccion;
        }

        // function getMontoLetra(number, lenguaje) {
        //     var spellOut = i18n.spellOut({
        //         number: number,
        //         locale: lenguaje
        //     });
        //
        //     log.debug(spellOut);
        //
        //     var texto = spellOut.split(" coma");
        //
        //     var traduccion = texto[0] + ' ' + texto[1] + "/100 ";
        //
        //     return traduccion;
        // }

        function formatDate(value) {

            var date = new Date(format.parse({value: value, type: format.Type.DATE}));

            var meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

            var date2 = date.getDate() + ' de ' + meses[date.getMonth()] + ' ' + date.getFullYear();

            return date2;
        }

        function renderizarPDF() {

            try {

                log.audit({
                    title: 'Renderizar Pdf con datos',
                    details: glbPdfData
                });

                var renderer = render.create();

                renderer.setTemplateById('138');
                renderer.addCustomDataSource({
                    format: render.DataSource.JSON,
                    alias: "DATA",
                    data: JSON.stringify(glbPdfData)
                });

                return renderer.renderAsPdf();

            } catch (e) {
                log.error({
                    title: 'renderizarPDF - error',
                    details: e.toString()
                });
            }
        }

        return {
            onRequest: onRequest
        }
    });

