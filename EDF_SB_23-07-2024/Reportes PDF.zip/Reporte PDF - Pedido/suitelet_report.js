/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */

define(['N/record', 'N/search', 'N/render', 'N/file', 'N/xml', 'N/format/i18n'], function (record, search, render, file, xml, format) {
    // custtmpl150_4681008_sb1_372
    function onRequest(context) {
        try {
            var response = context.response;
            var id = JSON.parse(context.request.parameters.value);
            var render_pdf = render.create();
            var datosJson;

            var records = record.load({
                type: record.Type.PURCHASE_ORDER,
                id: id,
                isDynamic: true,
            });
            var formato_pdf = records.getValue('custbody_tkio_form_clausu_impres');
            log.audit("formato_pdf", formato_pdf);
            // !pdfID SB = 165 || PROD = 148 || New SB = 150
            var pdfId = 150;
            datosJson = buildDataPDF_default(context, records);
            log.audit({ title: "datosJason", details: datosJson });
            log.audit({ title: "datosJason.calcYconfig", details: datosJson.calcYconfig });
            render_pdf.setTemplateById(pdfId);
            var transactionFile = null;
            render_pdf.addCustomDataSource({ format: render.DataSource.OBJECT, alias: "RECORD_PDF", data: datosJson });
            transactionFile = render_pdf.renderAsPdf();
            response.writeFile({
                file: transactionFile,
                isInline: true
            });
        } catch (e) {
            log.error("ERROR", e);
            response.write("INFO: Ha ocurrido un error al intentar crear la plantilla");
            return;
        }
    }

    function buildDataPDF_default(context, records) {
        try {
            var id = JSON.parse(context.request.parameters.value);
            log.audit({ title: 'url:', details: id });

            //obtener datos de la orden de compra
            var counts = records.getLineCount({
                sublistId: 'item'
            });
            var proveedor = records.getValue('entity');
            var subsidiaria = records.getValue('subsidiary');
            var total = records.getValue('total');
            var subtotal = records.getValue('subtotal');
            var taxtotal = records.getValue('taxtotal');
            var currency = records.getText('currency');
            var employee = records.getValue('employee');
            var ubicacion_ped = records.getValue('location');
            var printLabel = records.getValue('custbody_tko_print_label');
            var numero_pedSearch = records.getValue('id');
            var creadorName = '';

            var folio_servicios = records.getValue('custbody_tkio_serv_registrados');
            var serviciosEspecializados = records.getValue('custbody_tkio_serv_esp_reg');
            var numTrabajadores = records.getValue("custbody_tkio_num_trabajadores");
            var usuarioName = ''//records.getValue("custbody_fb_print_po_user_name");
            var usuarioEmail = ''// records.getValue("custbody_fb_print_po_user_email");

            let idSolicitante = records.getValue({ fieldId: 'custbody_fb_print_po_solicitante_serv' })
            if (idSolicitante) {
                var objEmployee = search.lookupFields({
                    type: search.Type.EMPLOYEE,
                    id: idSolicitante,
                    columns: ['firstname', 'lastname', 'email']
                });
                log.debug({ title: 'Objeto empleado:', details: objEmployee })
                usuarioName = (objEmployee.firstname || ' ') + ' ' + (objEmployee.lastname || ' ')
                usuarioEmail = objEmployee.email || ' '
            }

            var totales_format = format.getCurrencyFormatter({ currency: currency });
            var totales_symbol = totales_format.symbol;
            totales_format = totales_format.numberFormatter;

            // ---------------------------------------------------------------------------------------------------
            var purchaserequisitionSearchObj = search.create({
                type: "purchaserequisition",
                filters:
                    [
                        ["type", "anyof", "PurchReq"]
                    ],
                columns:
                    [
                        search.createColumn({ name: "internalid", label: "ID interno" }),
                        search.createColumn({ name: "applyingtransaction", label: "Aplicación de transacción" })
                    ]
            });
            var myPagedResults = purchaserequisitionSearchObj.runPaged({
                pageSize: 1000
            });
            var thePageRanges = myPagedResults.pageRanges;
            var idsolped, numeroPedido, bandera = false;
            for (var i in thePageRanges) {
                var thepageData = myPagedResults.fetch({
                    index: thePageRanges[i].index
                });
                thepageData.data.forEach(function (result) {
                    if (bandera == false) {
                        numeroPedido = result.getValue({ name: 'applyingtransaction' });
                        if (numeroPedido == numero_pedSearch) {
                            idsolped = result.getValue({ name: 'internalid' });
                            log.audit({ title: 'Relacion Pedido-solped', details: { pedido: numeroPedido, solped: idsolped } });
                            bandera = true;
                        }
                        return true;
                    } else {
                        return false;
                    }
                });
                if (bandera == true) {
                    break;
                }
            }
            if (idsolped) {
                var nameOrigen = search.lookupFields({
                    type: 'purchaserequisition',
                    id: idsolped,
                    columns: ['entity']
                });
                creadorName = nameOrigen.entity[0].text;
                log.audit({ title: 'CreadorName', details: creadorName });
            }
            // ---------------------------------------------------------------------------------------------------


            if (ubicacion_ped) {
                var records_location = record.load({
                    type: record.Type.LOCATION,
                    id: ubicacion_ped,
                    isDYnamic: true,
                });
                var direccion_location = records_location.getValue('mainaddress_text') || '';
                log.audit("Location en el if", direccion_location);
            } else {
                var direccion_location = '';
                log.audit("Location en el else", direccion_location);
            }
            var iniciales_comprador = ""
            if (employee) {
                var records_employee = record.load({
                    type: record.Type.EMPLOYEE,
                    id: employee,
                    isDynamic: true,
                });

                var firstname = records_employee.getValue('firstname');
                var secondlame = records_employee.getValue('lastname');
                var initals = records_employee.getValue('initials');
                var emailEmployee = records_employee.getValue({ fieldId: 'email' });

                var nombre_empleado = firstname + ' ' + secondlame;
                iniciales_comprador = initals

            } else {
                var nombre_empleado = '';
            }

            //Buscar datos del proveedor
            // var proveedor_

            //buscar datos de subsidiaria
            var subsidiary_record = record.load({
                type: record.Type.SUBSIDIARY,
                id: subsidiaria,
                isDynamic: true,
            });

            var subsidiary_rfc = subsidiary_record.getValue('federalidnumber');
            var subsidiary_adress = subsidiary_record.getValue('mainaddress_text');
            var subsidiary_phone = subsidiary_record.getValue('phone') || '5482 5260';
            var subsidiary_name = subsidiary_record.getValue('legalname');
            // var subsidiaryArray = subsidiary_name.split(', ');
            // subsidiary_name = subsidiaryArray[0];
            var subsidiary_logo_url = subsidiary_record.getValue('logo');
            if (subsidiary_logo_url) {
                var file_logo = file.load({ id: subsidiary_logo_url });
                var subsidiary_logo = file_logo.url;
            } else {
                var subsidiary_logo = '';
            }

            //obtener datos de la solicitud de compra
            var solped = records.getSublistValue({
                sublistId: 'item',
                fieldId: 'linkedorder',
                line: 0
            });
            log.audit({ title: 'solped', details: solped });
            var empleado = '';
            if (solped[0]) {
                log.audit({ title: 'enter', details: 'entró' });
                var solicitud = record.load({
                    type: record.Type.PURCHASE_REQUISITION,
                    id: solped[0],
                    isDynamic: true,
                });
                var solicitante = solicitud.getValue('entity');
                //obtener datos del solicitante
                empleado = record.load({
                    type: record.Type.EMPLOYEE,
                    id: solicitante,
                    isDynamic: true,
                });
            }
            //obtener datos del contacto del proveedor
            var contactos = search.create({
                type: search.Type.CONTACT,
                filters: [['company', search.Operator.IS, proveedor]
                    , 'and',
                ['role', search.Operator.IS, '-10']
                ],
                columns: [
                    search.createColumn({ name: 'email' }),
                    search.createColumn({ name: 'firstname' })
                ]
            });
            var ejecutar = contactos.run();
            var resultado = ejecutar.getRange(0, 100);
            log.audit({ title: 'proveedor: ', details: proveedor });
            log.audit({ title: 'rol: ', details: resultado });
            //Obtener datos del proveedor
            var proveedor_data = record.load({
                type: record.Type.VENDOR,
                id: proveedor,
                isDynamic: true
            });

            var texto_a = '';
            var texto_b = '';
            var texto_c = '';
            var nombre_proveedor = '';
            var isperson = proveedor_data.getValue('isperson');
            var numStps = proveedor_data.getValue('custentity_tkio_num_reg_padron_stps')

            // var regiFiscal = proveedor_data.getValue('custentity_fb_regimenfiscal_proveedor');

            if (isperson == 'T') {
                var firstnameProv = proveedor_data.getValue('firstname');
                var secondlameProv = proveedor_data.getValue('lastname');
                var nombre_proveedor = firstnameProv + ' ' + secondlameProv;

                // nombre_proveedor = proveedor_data.getValue('glommedname');
                // texto_a = ' Que es una persona física con actividad empresarial.';
                // texto_b = ' Que goza de capacidad suficiente para celebrar la presente OC.';
                texto_a = ' Que es una Persona Física.';
                texto_b = ' Que su régimen fiscal es ';
                texto_c = ' Que goza de capacidad suficiente para celebrar la presente OC.'

            }
            
            if (isperson == 'F') {
                nombre_proveedor = proveedor_data.getValue('companyname');
                // texto_a = ' Que su representada es una sociedad mercantil legalmente constituida de conformidad con las leyes de la República Mexicana.';
                // texto_b = ' Que su Representante Legal tiene las facultades legales para celebrar la presente OC, y para obligar a su representada en el cumplimiento de las condiciones que el se estipulan.';
                texto_a = 'Que su representada es una sociedad mercantil legalmente constituida de conformidad con las leyes de la República Mexicana.'
                texto_b = 'Que tiene un régimen fiscal ';
                texto_c = 'Que su Representante Legal tiene las facultades legales para celebrar la presente OC, y para obligar a su representada en el cumplimiento de las condiciones que el se estipulan.'
            }
            log.audit({ title: 'nombre_proveedor:', details: nombre_proveedor });
            //obtener datos de los hitos de pago
            var hitos = search.create({
                type: 'customrecord_csc_hito_pago',
                filters: [['custrecord_csc_transaccion', search.Operator.IS, id]],
                columns: [
                    search.createColumn({ name: 'custrecord_csc_descripcion_hito' }),
                    search.createColumn({ name: 'custrecord_csc_importe' }),
                    search.createColumn({ name: 'custrecord_csc_termino_pago' })
                ]
            });
            var ejecutar_hitos = hitos.run();
            var resultado_hitos = ejecutar_hitos.getRange(0, 100);

            //Obtener fechas
            var fecha_emision = new Date();
            fecha_emision = records.getValue('trandate');
            if (fecha_emision) {
                var date_emision = fecha_emision.getDate() + '/' + (fecha_emision.getMonth() + 1) + '/' + fecha_emision.getFullYear();
            } else {
                var date_emision = fecha_emision;
            }


            var fecha_entrega = records.getValue('duedate');
            if (fecha_entrega) {
                var date_entrega = fecha_entrega.getDate() + '/' + fecha_entrega.getMonth() + '/' + fecha_entrega.getFullYear();
            } else {
                var date_entrega = fecha_entrega;
            }

            var datosNotasSistema = getDataNotasSistema(id);

            var fecha_aprobacion_finanzas = ""
            var iniciales_aprobador_finanzas = ""
            var fecha_aprobacion_presupuesto = ""
            var iniciales_aprobador_presupuesto = ""
            var banderapresupuesto = false;
            var banderafinanzas = false;
            if (datosNotasSistema.success) {
                log.audit({ title: 'datosNotasSistema.notas', details: datosNotasSistema.notas });
                log.audit({ title: 'datosNotasSistema.notas.length', details: datosNotasSistema.notas.length });
                var contadorNotas = datosNotasSistema.notas.length
                for (var i = 0; i < contadorNotas; i++) {
                    if (datosNotasSistema.notas[i].campo == "custbody_efx_aprob_presupuesto" && datosNotasSistema.notas[i].valor == "T" && banderapresupuesto == false) //si finanzas aprobo
                    {
                        banderapresupuesto = true;
                        fecha_aprobacion_finanzas = (datosNotasSistema.notas[i].fecha)
                        fecha_aprobacion_finanzas = fecha_aprobacion_finanzas.split(' ');
                        fecha_aprobacion_finanzas = fecha_aprobacion_finanzas[0];
                        iniciales_aprobador_finanzas = datosNotasSistema.notas[i].inicialesEmpleado
                    }
                    if (datosNotasSistema.notas[i].campo == "custbody_efx_aprob_fin" && datosNotasSistema.notas[i].valor == "T" && banderafinanzas == false) {
                        banderafinanzas = true;
                        fecha_aprobacion_presupuesto = (datosNotasSistema.notas[i].fecha);
                        fecha_aprobacion_presupuesto = fecha_aprobacion_presupuesto.split(' ');
                        fecha_aprobacion_presupuesto = fecha_aprobacion_presupuesto[0];
                        iniciales_aprobador_presupuesto = datosNotasSistema.notas[i].inicialesEmpleado
                    }
                }
            } else {

            }

            var datosJson = new Object();
            log.audit({ title: 'fecha_aprobacion_presupuesto', details: fecha_aprobacion_presupuesto });
            log.audit({ title: 'fecha_aprobacion_finanzas', details: fecha_aprobacion_finanzas });
            log.audit({ title: 'iniciales_aprobador_presupuesto', details: iniciales_aprobador_presupuesto });
            log.audit({ title: 'iniciales_aprobador_finanzas', details: iniciales_aprobador_finanzas });
            //////////////////////////  INICIO DATOS FLUJO DE APROBACION//////////////////// Primero es presupuesto y al final finanzas
            datosJson.fecha_aprobacion_presupuesto = fecha_aprobacion_presupuesto;        //FECHAS
            datosJson.fecha_aprobacion_finanzas = fecha_aprobacion_finanzas;           //FECHAS

            datosJson.iniciales_aprobador_presupuesto = iniciales_aprobador_presupuesto;     //INICIALES
            datosJson.iniciales_aprobador_finanzas = iniciales_aprobador_finanzas;        //INICIALES
            //////////////////////////  FIN DATOS FLUJO DE APROBACION   ////////////////////7

            datosJson.id = id;
            datosJson.vendor_email = records.getValue('custbody_nsts_vp_vendor_email') || '';
            datosJson.fecha_emision = date_emision;
            datosJson.fecha_entrega = date_entrega;
            datosJson.num_pedido = records.getValue('tranid') || '';
            datosJson.memo = records.getValue('memo') || '';
            datosJson.razon_social = nombre_proveedor || '';
            datosJson.billadress = records.getValue('billaddress') || '';
            datosJson.direccion_entrega = records.getValue('custbody_csc_direccionentregadif') || '';
            datosJson.rep_legal_subsidiary = records.getValue('custbody_efx_replegal_subsidiary') || '';
            datosJson.rep_legal_vendor = proveedor_data.getValue('custentity_efx_replegal') || '';
            datosJson.texto_a = texto_a;
            datosJson.texto_b = texto_b;
            datosJson.texto_c = texto_c;
            datosJson.comprador = nombre_empleado;
            datosJson.comprador_iniciales = iniciales_comprador;
            datosJson.creadorName = creadorName;
            datosJson.clausulado = records.getValue({ fieldId: 'custbody_tkio_form_clausu_impres' }) || '';
            datosJson.metodo_pago = records.getText('custbody_ix_ge_metod_pago') || '';

            if (datosJson.direccion_entrega == '') {
                datosJson.direccion_entrega = direccion_location || '';
            }

            datosJson.terminos = records.getText('terms');
            datosJson.incoterm = records.getText('incoterm') || 'N/A';
            if (solped[0]) {
                datosJson.email_solicitante = empleado.getValue('email') || '';
                datosJson.rep_legal = empleado.getValue('custentity_efx_replegal') || '';
                datosJson.email_usuario = empleado.getValue('email') || '';
                datosJson.name_usuario = empleado.getValue('altname') || '';
            } else {
                datosJson.email_solicitante = emailEmployee || nombre_empleado;
                datosJson.email_usuario = usuarioEmail;
                datosJson.name_usuario = usuarioName;
            }
            datosJson.solicitud_servicio = records.getText({ fieldId: 'custbody_fb_print_po_solicitante_serv' });
            // log.debug({title: 'datos_json',details:datosJson})
            log.audit({ title: 'result email_contacto_principal', details: resultado });
            if (resultado[0]) {
                datosJson.email_contacto_principal = resultado[0].getValue({ name: 'email' }) || '';
                //datosJson.rep_legal = resultado[0].getValue({name: 'firstname'}) || '';
            } else {
                datosJson.email_contacto_principal = '';
            }
            // log.debug({title: 'datos_json',details:datosJson})
            var claveElector = proveedor_data.getValue("custentity_tkio_clave_elector") || '';
            // datosJson.email_contacto_principal = proveedor_data.getValue('email') || '';
            // log.debug({title: 'datos_json',details:datosJson})
            datosJson.mail_vendor = proveedor_data.getValue('email') || '';
            datosJson.telefono_vendor = proveedor_data.getValue('phone') || '';
            datosJson.rfc_vendor = proveedor_data.getValue('vatregnumber') || '';
            datosJson.subsidiaria = subsidiary_name;
            datosJson.subsidiaria_adress = subsidiary_adress;
            datosJson.subsidiaria_rfc = subsidiary_rfc;
            datosJson.subsidiaria_phone = subsidiary_phone;
            datosJson.subsidiaria_logo = subsidiary_logo;
            datosJson.proveedor = proveedor;
            datosJson.empleado = employee;
            // log.debug({title: 'datos_json',details:datosJson})
            datosJson.total = totales_symbol + totales_format.format({ number: total });
            datosJson.subtotal = totales_symbol + totales_format.format({ number: subtotal });
            datosJson.taxtotal = totales_symbol + totales_format.format({ number: taxtotal });
            datosJson.currency = currency;
            datosJson.linkedorder = solped;
            datosJson.printlabel = printLabel ? 'T' : 'F';

            datosJson.folioServicios = folio_servicios;
            datosJson.serviciosEspecializados = serviciosEspecializados;
            datosJson.claveElector = claveElector;
            datosJson.numTrabajadores = numTrabajadores;
            datosJson.numStps = numStps;
            // datosJson.declaracion = records.getValue("custbody_fb_declaracion_f_m");
            // log.debug({title: 'datos_json',details:datosJson})
            // datosJson.regimenFiscal = records.getValue('custbody_tkio_regimen_fiscal_trans');
            var regimenId = records.getValue('custbody_tkio_regimen_fiscal_trans');
            var regimen = { custrecord_mx_sat_it_code: '' };
            // var regimen = '';
            if (regimenId) {
                regimen = search.lookupFields({
                    type: "customrecord_mx_sat_industry_type",
                    id: regimenId,
                    columns: ['custrecord_mx_sat_it_code']
                });
            }
            log.debug({ title: 'regimen', details: regimen })
            // datosJson.regimensubsidiaria = records.subsidiary.custrecord_mx_sat_industry_type;
            // Se toma el regimen fiscal de la subsidiaria
            var subsidiariaregimen = records.getValue('subsidiary')
            var regimensubsidiaria = search.lookupFields({
                type: search.Type.SUBSIDIARY,
                id: subsidiariaregimen,
                columns: ['custrecord_mx_sat_industry_type']
            });
            var regisubsi = (regimensubsidiaria.custrecord_mx_sat_industry_type[0] ? regimensubsidiaria.custrecord_mx_sat_industry_type[0].text : ' ');
            log.debug({ title: 'regimenSubsidiaria', details: regisubsi });
            datosJson.regimensub = regisubsi.toUpperCase();
            // ============================================================
            datosJson.regimenFiscal = (regimen.custrecord_mx_sat_it_code) ? regimen.custrecord_mx_sat_it_code : '';
            log.debug({ title: 'datos_json', details: datosJson })
            datosJson.observaciones = records.getValue('custbody_tkio_observaciones');

            var jsonGlobal = JSON.parse(records.getValue('custbody_efx_fe_tax_json'));
            log.debug({ title: 'jsonGlobal', details: jsonGlobal });

            var tasa_16 = '0.00';
            var ret_iva = '0.00';
            var ret_isr = '0.00';
            var ret_iva23 = "0.00";
            var arrKeys = [];

            for (let clave in (jsonGlobal.rates_retencion_data)) {
                if (clave === "16" || clave === "4") {
                    ret_iva = jsonGlobal.rates_retencion_data[clave];
                }
                if (clave === "10") {
                    ret_isr = jsonGlobal.rates_retencion_data[clave]
                }
            }

            if (Object.keys(jsonGlobal.rates_iva_data).length !== 0) {
                tasa_16 = jsonGlobal.rates_iva_data[16];
            }

            var taxGlobal = {};
            taxGlobal.retIva = ret_iva;
            taxGlobal.retIsr = ret_isr;
            taxGlobal.retIva23 = ret_iva23;
            taxGlobal.tasa = tasa_16;
            log.debug({ title: 'taxGlobal', details: taxGlobal });
            datosJson.impuestosGb = taxGlobal;

            datosJson.items = [];
            datosJson.hitos = [];

            var objItem = {};
            // objItem.index = '<b style="color:#001a70;font-size: 8pt;">N°</b>';
            // objItem.item_name = printLabel ? 'DESCRIPCIÓN DE LOS SERVICIOS ESPECIALIZADOS U OBRAS ESPECIALIZADAS' : 'DESCRIPCIÓN DE BIENES Y SERVICIOS';
            // objItem.mpn = '<b style="color:#001a70;font-size: 8pt;">NUMERO DE PARTE</b>';
            // objItem.quantity = '<b style="color:#001a70;font-size: 8pt;">CANTIDAD</b>';
            // objItem.units = '<b style="color:#001a70;font-size: 8pt;">UNIDAD DE MEDIDA</b>';
            // objItem.expecteddate = '<b style="color:#001a70;font-size: 8pt;">FECHA DE ENTREGA</b>';
            // objItem.rate = '<b style="color:#001a70;font-size: 8pt;">PRECIO UNITARIO</b>';
            // objItem.amount = '<b style="color:#001a70;font-size: 8pt;">IMPORTE</b>';

            // objItem.impuestos = '<b style="color:#001a70;font-size: 8pt;">IMPUESTOS</b>';
            // objItem.infoFacturacion = '<b style="color:#001a70;font-size: 8pt;">INFORMACIÓN DE FACTURACIÓN</b>';
            // objItem.condicionesPago = '<b style="color:#001a70;font-size: 8pt;">CONDICIONES DE PAGO</b>';

            // datosJson.items.push(objItem);
            //Función para la obtención de los tatos de los articulos y códigos de impuesto del articulo.
            let imp_des = getDesgloseImpuestos(id, records, counts, subsidiariaregimen);
            log.debug({ title: 'imp_des.dataItems 👻', details: imp_des.dataItems });
            log.debug({ title: 'imp_des.dataCalImp 👻👻', details: imp_des.dataTaxImp });
            // log.debug({ title: 'imp_des.configImpues 👻👻👻', details: imp_des.configImpues });
            var impuesCalc = new Object()
            var calcYconfig = new Object()
            for (var i = 0; i < counts; i++) {
                objItem = {};
                objItem.index = i + 1;
                objItem.item = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item',
                    line: i
                });
                objItem.item_name = records.getSublistText({
                    sublistId: 'item',
                    fieldId: 'item',
                    line: i
                });
                try {
                    var item_mpn = record.load({
                        type: record.Type.INVENTORY_ITEM,
                        id: objItem.item,
                        isDynamic: true,
                    });
                    objItem.mpn = item_mpn.getValue('mpn');
                }
                catch (err) {
                    objItem.mpn = '';
                }
                if (!objItem.mpn) {
                    objItem.mpn = '';
                }
                objItem.description = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'description',
                    line: i
                });
                objItem.units = records.getSublistText({
                    sublistId: 'item',
                    fieldId: 'units',
                    line: i
                });
                fecha_esperada = records.getSublistText({
                    sublistId: 'item',
                    fieldId: 'expectedreceiptdate',
                    line: i
                });
                var fecha_expected = new Date();
                if (fecha_emision) {
                    objItem.expecteddate = fecha_expected.getDate() + '/' + (fecha_expected.getMonth() + 1) + '/' + fecha_expected.getFullYear();
                } else {
                    objItem.expecteddate = fecha_expected;
                }
                objItem.quantity = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity',
                    line: i
                });
                
                objItem.grossamt = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'grossamt',
                    line: i
                }) + "";
                var item_rate = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: i
                });
                //========== INFO NUEVA DEL DRD =======================
                var impuestos = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_efx_fe_tax_json',
                    line: i
                });
                var objImp = JSON.parse(impuestos);
                var codeTax = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'taxcode',
                    line: i
                });
                // Calculo de impuestos por articulo
                var taxCal = 0;
                var taxDes = 0;
                taxDes = imp_des.dataTaxImp[codeTax];
                let importeArt = imp_des.dataItems[i].baseImporte;
                for (let x = 0; x < taxDes.length; x++) {
                    var taxItems = new Object();
                    taxCal = ((taxDes[x].taxRate) / 100) * importeArt;
                    taxItems[taxDes[x].taxId] = taxCal;
                    if (!impuesCalc[i]) {
                        impuesCalc[i] = [];
                    }
                    impuesCalc[i].push(taxItems);
                };
                //Mapeo de tipo de impuesto por articulo.
                for (const key in impuesCalc[i]) {
                    var configYcal = new Object();
                    // var typeYcal = new Object();
                    if (impuesCalc[i].hasOwnProperty(key)) {
                        // key es la posicion del in puesto por articulo dentro del arreglo.
                        // impuesCalc[i][key] es un objeto en la posición i con la posición del arreglo key
                        let idTax = impuesCalc[i][key];
                        let configImpuestos = imp_des.configImpues[0];
                        for (var config in configImpuestos) {
                            let configSelec = configImpuestos[config];
                            if (configSelec.length > 0) {
                                for (const k in configSelec) {
                                    for (const ke in idTax) {
                                        if (configSelec[k] == ke) {
                                            switch (config) {
                                                case 'config_iva':
                                                    configYcal['IVA'] = idTax[ke];
                                                    if (!calcYconfig[i]) {
                                                        calcYconfig[i] = [];
                                                    }
                                                    calcYconfig[i].push(configYcal);
                                                    break;
                                                case 'config_retencion':
                                                    for (let x in taxDes) {
                                                        if (x == key) {
                                                            var typeTax = taxDes[key].taxTipo.toUpperCase();
                                                            var arTypeTax = typeTax.split(' ');
                                                            if (arTypeTax[0] == 'IVA') {
                                                                configYcal['RET_IVA'] = idTax[ke];
                                                                break;
                                                            } else {
                                                                configYcal['RET_ISR'] = idTax[ke];
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    if (!calcYconfig[i]) {
                                                        calcYconfig[i] = [];
                                                    }
                                                    calcYconfig[i].push(configYcal);
                                                    break;
                                                case 'config_exento':
                                                    for (let x in taxDes) {
                                                        if (x == key) {
                                                            var typeTax = taxDes[key].taxTipo.toUpperCase();
                                                            var arTypeTax = typeTax.split(' ');
                                                            if (arTypeTax[0] == 'IVA') {
                                                                configYcal['IVA_EXEN'] = idTax[ke];
                                                                break;
                                                            } else {
                                                                configYcal['ISR_EXEN'] = idTax[ke];
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    if (!calcYconfig[i]) {
                                                        calcYconfig[i] = [];
                                                    }
                                                    calcYconfig[i].push(configYcal);
                                                    break;
                                                default:
                                                    configYcal[config] = idTax[ke];
                                                    if (!calcYconfig[i]) {
                                                        calcYconfig[i] = [];
                                                    }
                                                    calcYconfig[i].push(configYcal);
                                                    break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        log.debug({title:'ERROR in configYcal',details:'ERROR in configYcal'});
                    }
                };
                /*var objImpuestos = {
                    IVA: (objImp.iva.importe) ? (objImp.iva.importe) : "0.00",
                    RET_ISR: [{}],
                };
                if(objImp.retenciones.rate>0){
                    objImpuestos.RET_ISR.push({
                        importe_iva:(objImp.retenciones.name.split(' ', 1) == "IVA")?objImp.retenciones.importe:'0.00',
                        importe_isr:(objImp.retenciones.name.split(' ', 1) == "ISR")?objImp.retenciones.importe:'0.00'
                    });
                }else{
                    objImpuestos.RET_ISR.push('0.00');
                }
                objItem.impuestos = objImpuestos;*/
                var terminos = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_tkio_term_pago',
                    line: i
                });
                // log.debug({ title: 'terminos: ', details: terminos });
                var terminoName = '';
                if (terminos) {
                    terminoName = search.lookupFields({
                        type: 'term',
                        id: terminos,
                        columns: ['name']
                    });
                }
                var forma = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_tkio_forma_de_pago_display',
                    line: i
                });
                var cfdi = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_tkio_uso_cfdi_art_display',
                    line: i
                });
                var objInfoFacturacion = {
                    terminos: (terminoName.name) ? (terminoName.name) : '',
                    formaPago: forma,
                    cfdi: cfdi
                }
                objItem.infoFact = objInfoFacturacion;
                let condicionPago= records.getSublistText({
                    sublistId: 'item',
                    fieldId: 'custcol_tkio_condiciones_pago',
                    line: i
                });
                objItem.condicionesText='';
                objItem.condicionesTextf='';
                if (condicionPago != ''){
                    condicionPago= condicionPago.split('__').join(objInfoFacturacion.terminos)
                    objItem.condicionesText=condicionPago
                }
                let condicionFacturacion = records.getSublistText({
                    sublistId: 'item',
                    fieldId: 'custcol_fb_condiciones_facturacion',
                    line: i
                });
                objItem.condicionesTextf=condicionFacturacion
                objItem.condicionesPago = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_tkio_condiciones_pago',
                    line: i
                });
                var format_rate = format.getCurrencyFormatter({ currency: currency });
                var symbol_rate = format_rate.symbol;
                format_rate = format_rate.numberFormatter;
                objItem.rate = symbol_rate + format_rate.format({ number: item_rate });
                var item_amount = records.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: i
                });
                var format_amount = format.getCurrencyFormatter({ currency: currency });
                var symbol_amount = format_amount.symbol;
                format_amount = format_amount.numberFormatter;
                objItem.amount = symbol_amount + format_amount.format({ number: item_amount });
                datosJson.items.push(objItem);
            }
            datosJson.calcYconfig = {};
            datosJson.calcYconfig = JSON.stringify(calcYconfig);
            /*var arrMapTax = [];
            log.debug({
                title: 'taxDes',
                details: taxDes
            })
            imp_des.dataItems.forEach((item, index) => {
                log.debug({
                    title: 'Item new:',
                    details: item
                })
                let taxPiv = imp_des.dataTaxImp[item.taxCode].find((taxP)=>taxP.taxId == item.taxCode)
                let objPiv = { [item.taxCode]: { taxPiv } }
                arrMapTax.push(objPiv)
            })
            log.debug({
                title: 'Arreglo new:',
                details: arrMapTax
            })*/
            log.debug({ title: 'taxCal', details: impuesCalc });
            log.debug({ title: 'calcYconfig', details: calcYconfig });
            // log.debug({ title: 'objImpuestos', details: objImpuestos });
            //llenar hitos de facturacion
            // log.audit({ title: 'resultado_hitos', details: resultado_hitos });
            if (resultado_hitos.length > 0) {
                var objHitos = {};
                objHitos.linea = 0;
                objHitos.descripcion_hito = '<b style="color:#001a70">Descripción del Hito</b>';
                objHitos.importe_hito = '<b style="color:#001a70">Importe</b>';
                objHitos.terminos_hito = '<b style="color:#001a70">Terminos</b>';
                datosJson.hitos.push(objHitos);
                var format_amount_hito = format.getCurrencyFormatter({ currency: currency });
                var symbol_amount_hito = format_amount_hito.symbol;
                format_amount_hito = format_amount_hito.numberFormatter;
                var hito_amount = '';
                for (var x = 0; x < resultado_hitos.length; x++) {
                    var objHitos = {};
                    objHitos.descripcion_hito = resultado_hitos[x].getValue({ name: 'custrecord_csc_descripcion_hito' });
                    hito_amount = parseFloat(resultado_hitos[x].getValue({ name: 'custrecord_csc_importe' }));
                    objHitos.importe_hito = symbol_amount_hito + format_amount_hito.format({ number: hito_amount });
                    objHitos.terminos_hito = resultado_hitos[x].getText({ name: 'custrecord_csc_termino_pago' });
                    datosJson.hitos.push(objHitos);
                }
            }
            return datosJson;
        } catch (e) {
            log.error("buildDataPDF_default Error", e);
        }
    }

    function getDesgloseImpuestos(Id_OC, tran_record, line_count, subsid) {
        try{
            //busqueda de configuración de impuestos
            let desglose_config = search.create({
                type: 'customrecord_efx_fe_desglose_tax',
                filters: ['isinactive', search.Operator.IS, 'F'],
                columns: [
                    search.createColumn({ name: 'custrecord_efx_fe_desglose_ieps' }),
                    search.createColumn({ name: 'custrecord_efx_fe_desglose_ret' }),
                    search.createColumn({ name: 'custrecord_efx_fe_desglose_locales' }),
                    search.createColumn({ name: 'custrecord_efx_fe_desglose_iva' }),
                    search.createColumn({ name: 'custrecord_efx_fe_desglose_exento' }),
                ]
            });
            let ejecutar = desglose_config.run();
            let resultado = ejecutar.getRange(0, 100);
            //Crea los arreglos
            let obj_tax = new Object();
            let config_Tax = new Object();
            let array_tax = new Array();
            config_Tax.config_ieps = (resultado[0].getValue({ name: 'custrecord_efx_fe_desglose_ieps' })).split(',');
            config_Tax.config_retencion = (resultado[0].getValue({ name: 'custrecord_efx_fe_desglose_ret' })).split(',');
            config_Tax.config_local = (resultado[0].getValue({ name: 'custrecord_efx_fe_desglose_locales' })).split(',');
            config_Tax.config_iva = (resultado[0].getValue({ name: 'custrecord_efx_fe_desglose_iva' })).split(',');
            config_Tax.config_exento = (resultado[0].getValue({ name: 'custrecord_efx_fe_desglose_exento' })).split(',');
            array_tax.push(config_Tax);
            obj_tax['configImpues'] = array_tax;
            //Se buscan los grupos de impuestos
            let nexo = tran_record.getValue({ fieldId: 'nexus_country' });
            var objImpuestos = obtenObjImpuesto(subsid, nexo);
            // log.debug({title:'objImpuestos ☠️',details:objImpuestos });
            //Recorrido de los items
            let data_items = [];
            let dataTaxImp = {};
            for (var i = 0; i < line_count; i++) { 
                let items = new Object();
                /*var base_quantity = tran_record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity',
                    line: i
                });*/
                var base_rate = tran_record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: i
                });
                if (!base_rate) {
                    var importe_amount = tran_record.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'amount',
                        line: i
                    });
                    base_rate = importe_amount / base_quantity;
                }
                var tax_code = tran_record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'taxcode',
                    line: i
                });
                var importe_base = tran_record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: i
                });
                // log.audit({ title: 'importe_base', details: importe_base });
                // items.quantity = base_quantity;
                items.baseRate = base_rate;
                items.taxCode = tax_code;
                items.baseImporte = importe_base;
                data_items.push(items);
                //Se hace el la busqueda de los códigos o grupos de impuesto
                var grupo_impuestos
                if (Object.keys(objImpuestos).length !== 0) {
                    if (objImpuestos.TaxGroup.hasOwnProperty(tax_code)) {
                        grupo_impuestos = true;
                        var tax_lines_count = objImpuestos.TaxGroup[tax_code].length;
                    } else if (objImpuestos.TaxCodes.hasOwnProperty(tax_code)) {
                        // log.audit({ title: 'objImpuestos.TaxCodes[tax_code]', details: objImpuestos.TaxCodes[tax_code] });
                        grupo_impuestos = false;
                        var tax_lines_count = 1;
                    }
                }
                for (var x = 0; x < tax_lines_count; x++) {
                    var imporTax = new Object();
                    if (grupo_impuestos) {
                        var tax_name = objImpuestos.TaxGroup[tax_code][x].taxname2;
                        var tax_id = objImpuestos.TaxGroup[tax_code][x].taxname;
                        var tax_rate = objImpuestos.TaxGroup[tax_code][x].rate;
                        var tax_base = objImpuestos.TaxGroup[tax_code][x].basis;
                        var tax_tipo = objImpuestos.TaxGroup[tax_code][x].taxtype;
                    } else {
                        var tax_name = objImpuestos.TaxCodes[tax_code][x].itemid;
                        var tax_id = objImpuestos.TaxCodes[tax_code][x].id;
                        var tax_rate = objImpuestos.TaxCodes[tax_code][x].rate;
                        var tax_base = '100';
                        var tax_tipo = objImpuestos.TaxCodes[tax_code][x].taxtype;
                    }
                    imporTax.taxName = tax_name;
                    imporTax.taxId = tax_id;
                    imporTax.taxRate = tax_rate;
                    imporTax.taxBase = tax_base;
                    imporTax.taxTipo = tax_tipo;
                    if (!dataTaxImp[tax_code]) {
                        dataTaxImp[tax_code] = [];
                    }
                    dataTaxImp[tax_code].push(imporTax);
                }
            }
            obj_tax['dataItems'] = data_items;
            obj_tax['dataTaxImp'] = dataTaxImp;
            // log.emergency({title:'data_item',details:obj_tax.dataTaxImp});
            return obj_tax;
        }catch(err){
        log.error({title:'Error occurred in getDesgloseImpuestos',details:err});
        }
    }

    function obtenObjImpuesto(subsidiariaTransaccion, nexo) {
        try{
            var objcodigosMainFull = {};
            var objcodigosMain = {};
            var objcodigosMainCodes = {};
            var arraybusquedagroup = new Array();
            var arraybusquedacode = new Array();
            arraybusquedagroup.push(["isinactive", search.Operator.IS, "F"]);
            arraybusquedacode.push(["isinactive", search.Operator.IS, "F"]);
            if (subsidiariaTransaccion) {
                arraybusquedagroup.push("AND");
                arraybusquedacode.push("AND");
                arraybusquedagroup.push(["subsidiary", search.Operator.ANYOF, subsidiariaTransaccion]);
                arraybusquedacode.push(["subsidiary", search.Operator.ANYOF, subsidiariaTransaccion]);
                arraybusquedagroup.push("AND");
                arraybusquedagroup.push(["country", search.Operator.ANYOF, nexo]);
                arraybusquedacode.push("AND");
                arraybusquedacode.push(["country", search.Operator.ANYOF, nexo]);
            }
            //busca grupos de impuestos
            var taxgroupSearchObj = search.create({
                type: search.Type.TAX_GROUP,
                filters: arraybusquedagroup,
                columns:
                    [
                        search.createColumn({ name: "itemid", }),
                        search.createColumn({ name: "rate", label: "Tasa" }),
                        search.createColumn({ name: "country", label: "País" }),
                        search.createColumn({ name: "internalid", label: "ID interno" })
                    ]
            });
            var ejecutar = taxgroupSearchObj.run();
            var resultado = ejecutar.getRange(0, 900);
            for (var i = 0; i < resultado.length; i++) {
                var tax_code = resultado[i].getValue({ name: "internalid" });
                var info_tax_rec = record.load({
                    type: record.Type.TAX_GROUP,
                    id: tax_code,
                    isDynamic: true
                });
                objcodigosMain[tax_code] = new Array();
                var tax_lines_count = info_tax_rec.getLineCount({ sublistId: 'taxitem' });
                for (var x = 0; x < tax_lines_count; x++) {
                    var objcodigos = {
                        taxname2: '',
                        taxname: '',
                        rate: '',
                        basis: '',
                        taxtype: '',
                    }
                    objcodigos.taxname2 = info_tax_rec.getSublistValue({
                        sublistId: 'taxitem',
                        fieldId: 'taxname2',
                        line: x
                    });
                    objcodigos.taxname = info_tax_rec.getSublistValue({
                        sublistId: 'taxitem',
                        fieldId: 'taxname',
                        line: x
                    });
                    objcodigos.rate = info_tax_rec.getSublistValue({
                        sublistId: 'taxitem',
                        fieldId: 'rate',
                        line: x
                    });
                    objcodigos.basis = info_tax_rec.getSublistValue({
                        sublistId: 'taxitem',
                        fieldId: 'basis',
                        line: x
                    });
                    objcodigos.taxtype = info_tax_rec.getSublistValue({
                        sublistId: 'taxitem',
                        fieldId: 'taxtype',
                        line: x
                    });
                    objcodigosMain[tax_code].push(objcodigos);
                }
            }
            // =============Grupo de impuesto================
            //busca codigos de impuestos
            var salestaxitemSearchObj = search.create({
                type: search.Type.SALES_TAX_ITEM,
                filters: arraybusquedacode,
                columns: [
                    search.createColumn({ name: "name", }),
                    search.createColumn({ name: "itemid", label: "ID de artículo" }),
                    search.createColumn({ name: "rate", label: "Tasa" }),
                    search.createColumn({ name: "country", label: "País" }),
                    //search.createColumn({name: "custrecord_4110_category", label: "Categoría"}),
                    search.createColumn({ name: "internalid", label: "ID interno" }),
                    search.createColumn({ name: "taxtype", label: "Tipo Impuesto" })
                ]
            });
            var ejecutar = salestaxitemSearchObj.run();
            var resultado = ejecutar.getRange(0, 900);
            //objcodigosMainCodes.codigos = new Array();
            for (i = 0; i < resultado.length; i++) {
                var tax_code = resultado[i].getValue({ name: "internalid" });
                objcodigosMainCodes[tax_code] = new Array();
                var objcodigos = {
                    itemid: '',
                    id: '',
                    rate: '',
                    basis: '100',
                    taxtype: '',
                }
                objcodigos.itemid = resultado[i].getValue({ name: "itemid" });
                objcodigos.id = resultado[i].getValue({ name: "internalid" });
                var ratecode = (resultado[i].getValue({ name: "rate" })).replace('%', '');
                objcodigos.rate = parseFloat(ratecode);
                objcodigos.basis = '100';
                objcodigos.taxtype = resultado[i].getText({ name: "taxtype" });
                objcodigosMainCodes[tax_code].push(objcodigos);
            }
            // =============Código de impuesto================
            objcodigosMainFull.TaxGroup = objcodigosMain;
            objcodigosMainFull.TaxCodes = objcodigosMainCodes;
            return objcodigosMainFull;
        }catch(err){
        log.error({title:'Error occurred in obtenObjImpuesto',details:err});
        }
    }

    function getDataNotasSistema(id_transaccion) {
        try {
            var responseSearch = {}
            var purchaseorderSearchObj = search.create({
                type: "purchaseorder",
                filters:
                    [
                        ["type", "anyof", "PurchOrd"],
                        "AND",
                        ["mainline", "is", "T"],
                        "AND",
                        ["internalid", "anyof", id_transaccion]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "recordtype",
                            join: "systemNotes",
                            label: "Tipo de registro"
                        }),
                        search.createColumn({
                            name: "field",
                            join: "systemNotes",
                            label: "Campo"
                        }),
                        search.createColumn({
                            name: "newvalue",
                            join: "systemNotes",
                            label: "Nuevo valor"
                        }),

                        search.createColumn({//Ordenado por fecha descendente
                            name: "date",
                            join: "systemNotes",
                            sort: search.Sort.DESC,
                            label: "Fecha"
                        }),
                        search.createColumn({
                            name: "name",
                            join: "systemNotes",
                            label: "Definido por"
                        })
                    ]
            });
            var searchResultCount = purchaseorderSearchObj.runPaged().count;
            log.audit("purchaseorderSearchObj result count", searchResultCount);
            if (searchResultCount) {
                var objetoDatos = []
                purchaseorderSearchObj.run().each(function (result) {
                    var ObjPedidoNotes = {}
                    var campo = result.getValue({ name: "field", join: "systemNotes" });
                    var valor = result.getValue({ name: "newvalue", join: "systemNotes" });
                    var fecha = result.getValue({ name: "date", join: "systemNotes" });
                    var id_empleado = result.getValue({ name: "name", join: "systemNotes" });
                    if (campo == "custbody_efx_aprob_fin" || campo == "custbody_efx_aprob_presupuesto") {
                        ObjPedidoNotes.campo = campo
                        ObjPedidoNotes.valor = valor
                        ObjPedidoNotes.fecha = fecha
                        //ObjPedidoNotes.id_empleado=id_empleado
                        var inicialesEmpleado = _getDataEmpleado(id_empleado)
                        ObjPedidoNotes.inicialesEmpleado = inicialesEmpleado
                        objetoDatos.push(ObjPedidoNotes);
                    }
                    return true;
                });
                responseSearch = {
                    notas: objetoDatos,
                    success: true,
                }
            } else {
                responseSearch = {
                    success: false
                }
            }


            return responseSearch;

        } catch (e) {
            log.error("ERROR getDataNotasSistema", e);
        }
    }

    function _getDataEmpleado(idEmpleado) {
        try {
            var employeeObj = record.load({
                type: record.Type.EMPLOYEE,
                id: idEmpleado
            });

            var inciales = employeeObj.getValue({ fieldId: 'initials' });
            log.audit({ title: 'inciales', details: inciales });
            return inciales
        } catch (e) {
            log.error("ERROR getDataEmpleado", e);
        }
    }

    return {
        onRequest: onRequest
    }
});