/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/log', 'N/record','N/search', 'N/format','N/format/i18n','N/url', 'N/file'],

    (log, record, search, format, i18n, url, file) => {
            /**
             * Defines the function definition that is executed before record is loaded.
             * @param {Object} scriptContext
             * @param {Record} scriptContext.newRecord - New record
             * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
             * @param {Form} scriptContext.form - Current form
             * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
             * @since 2015.2
             */
            const beforeLoad = (scriptContext) => {

            }

            /**
             * Defines the function definition that is executed before record is submitted.
             * @param {Object} scriptContext
             * @param {Record} scriptContext.newRecord - New record
             * @param {Record} scriptContext.oldRecord - Old record
             * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
             * @since 2015.2
             */
            const beforeSubmit = (scriptContext) => {
				try{

                    // objeto que contiene la sumatoria de impuestos
                    //var impuestos={IsrRet, IvaRetenido};

                    var bill = scriptContext.newRecord;

                    var SumaImporte=0;
                    var TotalIva=0;
                    var TotalIsrRetenido=0;
                    var TotalIvaRetenido=0;
                    var TotalIvaRetenido1=0;
                    var sumatotales=0;


                    var importe1 = bill.getValue({
                            fieldId:'usertotal'
                    });
                    //log.audit({title: 'importe:', details: importe1});

                    var lineCount = bill.getLineCount({
                            sublistId: 'expense'
                    });
                    var currency = bill.getValue({
                            fieldId: 'currency'
                    });

                    var lookUp = search.lookupFields({
                            type: search.Type.CURRENCY,
                            id: currency,
                            columns: ['symbol']
                    });



                    //log.debug({title: 'numero de lineas EXPENSE', details: lineCount});
                    for(var l=0;l<lineCount;l++){

                            var sublista = bill.getSublistValue({
                                    sublistId: 'expense',
                                    fieldId: 'expense',
                                    line: l
                            });
                            //log.debug({title: 'gastos', details: sublista});

                            var CodigoImpuesto = bill.getSublistValue({
                                    sublistId: 'expense',
                                    fieldId: 'taxcode',
                                    line: l
                            });

                            var importe = bill.getSublistValue({
                                    sublistId: 'expense',
                                    fieldId: 'amount',
                                    line: l
                            });
                            var SumaImporte = SumaImporte + importe;
                            if(CodigoImpuesto == 4744 || CodigoImpuesto == 4741 ){
                                    var recordTaxGroup = record.load({
                                            type: record.Type.TAX_GROUP,
                                            id: CodigoImpuesto ,
                                            isDynamic: true,
                                    });

                                    var numLines = recordTaxGroup.getLineCount({
                                            sublistId: 'taxitem'
                                    });
                                    log.debug({title: 'NUMERO DE LINEAS DE GRUPO DE IMPUESTO', details: numLines});
                                    for(var j=0;j<numLines;j++){

                                            var IdTipoGrupoImpuesto = recordTaxGroup.getSublistValue({

                                                    sublistId: 'taxitem',
                                                    fieldId: 'taxtype',
                                                    line: j

                                            });

                                            var IdTipoGrupoImpuesto = recordTaxGroup.getSublistValue({

                                                    sublistId: 'taxitem',
                                                    fieldId: 'taxname',
                                                    line: j

                                            });
                                            var Porcentaje = recordTaxGroup.getSublistValue({
                                                    sublistId: 'taxitem',
                                                    fieldId: 'rate',
                                                    line: j

                                            });
                                            //log.debug({title: 'PORCENTAJES ', details: Porcentaje});
                                            // 5311 IVA ARRENDAMIENTO EJIDATARIO , 4721 ISR RETENIDO POR ARRENDAMIENTO EJIDATARIO  4740 IVA Retenido Arrendamiento (10.667%)

                                            if(IdTipoGrupoImpuesto == 5311){
                                                    var PorcentajeIva = Porcentaje / 100;
                                                    var Iva = importe * PorcentajeIva;
                                                    log.debug({title: 'IVA', details: Iva});
                                                    var TotalIva = TotalIva + Iva;
                                            }
                                            if(IdTipoGrupoImpuesto == 4721){

                                                    // calcular el monto correspondiente a esta linea de la factura proveedor
                                                    var PorIsrRet = Porcentaje / 100;

                                                    var IsrRetenido = importe * PorIsrRet
                                                    log.debug({title: 'ISR RETENIDO ', details: IsrRetenido});
                                                    var TotalIsrRetenido = TotalIsrRetenido + IsrRetenido;
                                                    var numeroPositivo = Math.abs(TotalIsrRetenido);
                                            }

                                            else if(IdTipoGrupoImpuesto == 4740){

                                                    var PorIvaRet1 = Porcentaje / 100;
                                                    var IvaRetenido1 = importe * PorIvaRet1 ;

                                                    log.debug({title: 'IVA RETENIDO 16% ', details: IvaRetenido1});
                                                    TotalIvaRetenido1 = TotalIvaRetenido1 + IvaRetenido1;

                                            }

                                            if(IdTipoGrupoImpuesto == 5312){ // 5312 ID INTERNO TIPO DE IMPUESTO ARRENDAMIENTOS
                                                    var PorIvaRet = Porcentaje / 100;
                                                    var IvaRetenido = Iva / 3 * 2;
                                                    log.debug({title: 'IVA RETENIDO 10.667% ', details: IvaRetenido});

                                                    TotalIvaRetenido = TotalIvaRetenido + IvaRetenido;

                                                    var sum = TotalIvaRetenido;
                                            }


                                    }



                            }
                    }

                    var BillMontoLetra = getMontoLetra(importe1, lookUp.symbol).toUpperCase();
                    log.audit({title: 'montoletra:', details: BillMontoLetra});

                    function getMontoLetra(dato, symbol){


                            var spellOut = i18n.spellOut({
                                    number: dato,
                                    locale: "ES"
                            });

                            var importe1 = dato.toString().split('.');

                            if (importe1[1] == undefined) {
                                    importe1[1] = "00";
                            }
                            if(symbol == 'MXN'){
                                    symbol = 'MN'
                            }

                            var texto = spellOut.split(" coma");
                            var traduccion = texto[0] + " PESOS " + importe1[1] + "/100 " + symbol;
                            log.audit({title: 'letra:', details: traduccion});

                            return traduccion;

                    }
                    sumatotales =  TotalIvaRetenido - TotalIvaRetenido1;

                    bill.setValue({
                            fieldId: 'custbody_edf_sit_importe_total',
                            value: SumaImporte,
                            ignoreFieldChange: true
                    });

                    bill.setValue({
                            fieldId: 'custbody_edf_sit_iva',
                            value: TotalIva,
                            ignoreFieldChange: true
                    });

                    bill.setValue({
                            fieldId: 'custbody_ret_isr',
                            value: numeroPositivo,
                            ignoreFieldChange: true
                    });

                    bill.setValue({
                            fieldId: 'custbody_ret_iva',
                            value: sumatotales,
                            ignoreFieldChange: true
                    });
                    bill.setValue({
                            fieldId: 'custbody_bill_monto_en_letra',
                            value: BillMontoLetra,
                            ignoreFieldChange: true
                    });
                }
                catch(e){
					log.error({title: "beforeSubmit", details: e});
                }
              

            }
            /**
             * Defines the function definition that is executed after record is submitted.
             * @param {Object} scriptContext
             * @param {Record} scriptContext.newRecord - New record
             * @param {Record} scriptContext.oldRecord - Old record
             * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
             * @since 2015.2
             */
            const afterSubmit = (scriptContext) => {

            }

            return {beforeLoad, beforeSubmit, afterSubmit}

    });