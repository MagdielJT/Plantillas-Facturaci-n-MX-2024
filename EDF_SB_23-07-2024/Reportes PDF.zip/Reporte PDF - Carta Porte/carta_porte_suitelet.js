/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @summary Script que servirá para la generación de la pantalla para poder generar la carta porte
 */

define(['N/render', 'N/ui/serverWidget', './Controller/datos_registro.js', './Controller/errores_personalizados.js', 'N/search', './Controller/busquedas.js', 'N/record'],

    (_render, _serverWidget, datos_registros, _error, search, busquedas, record) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */

        var items = new Array();
        var linesNums = new Array();
        var itemsName = new Array();
        const _globales = Object.freeze({
            cartaporte_cl: './carteporte_cl.js'
        })

        const lista = ['Tipo_de_Ubicacion', 'RFC', 'Nombre', 'Calle', 'Ext', 'Int', 'Pais', 'Domicilio', 'Colonia', 'Localidad', 'Municipio', 'Estado', 'CP']
        const onRequest = (scriptContext) => {
            let seccion = ''
            try {

                seccion = 'Recopilando datos'; {
                    var RES = scriptContext.response
                    var REQ = scriptContext.request
                    var PARAM = REQ.parameters

                    /** Verificar que en los parametros sobre URL exista el id de la orden de compra, si no existe mandar error */
                    if (!PARAM.hasOwnProperty("ordenDeCompra")) {
                        throw new Error(400);
                    }

                    let ordendeCompra = PARAM.ordenDeCompra
                    let jsonRecord = datos_registros.cargarOrdenDeCompra(ordendeCompra);
                    log.debug({ title: 'jsonRecord', details: jsonRecord });
                    let objRecord = jsonRecord.objRecord;
                    log.debug({ title: 'objRecord', details: objRecord });
                    let numLines = objRecord.getLineCount({
                        sublistId: 'item'
                    });
                    log.debug({ title: 'numLines', details: numLines });

                    for (let i = 0; i < numLines; i++) {
                        var sublistFieldValue = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
                        var sublistFieldValueLine = Number(objRecord.getSublistValue({ sublistId: 'item', fieldId: 'line', line: i })) - 1;
                        var sublistFieldItemValue = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'item_display', line: i });
                        items.push(sublistFieldValueLine)
                        // items.push(sublistFieldValue);
                        itemsName.push(sublistFieldItemValue);
                    }
                    log.debug({ title: 'items', details: items });
                    log.debug({ title: 'linesNums', details: linesNums });
                    log.debug({ title: 'itemsName', details: itemsName });
                    seccion = 'Datos de busquedas'; {
                        datos_registros.datosDeEfx_fe_sat()
                    }
                    seccion = 'Cargar datos del registro'; {
                        datos_registros.cargarOrdenDeCompra(ordendeCompra)
                    }
                    log.debug({ title: 'datos_registros: ', details: datos_registros.cargarOrdenDeCompra(ordendeCompra) })

                }
                seccion = 'Creacion de formulario'; {
                    var formulario = _serverWidget.createForm({ title: 'Complemento - Carta Porte' })
                    //====================================DATOS CLIENTE=====================
                    let grupoRemitente = formulario.addFieldGroup({ id: 'custpage_grupodatosremitente', label: 'Datos del Cliente' })
                    let clienteOC = formulario.addField({ id: 'custpage_lblclientenombre', type: _serverWidget.FieldType.TEXT, label: 'Nombre: ', container: 'custpage_grupodatosremitente' })
                    let rfcClienteOC = formulario.addField({ id: 'custpage_lblclienterfc', type: _serverWidget.FieldType.TEXT, label: 'RFC: ', container: 'custpage_grupodatosremitente' })
                    let razonSocialClienteOC = formulario.addField({ id: 'custpage_lblrazonsocial', type: _serverWidget.FieldType.TEXT, label: 'Razón Social: ', container: 'custpage_grupodatosremitente' })
                    let direccionClienteOC = formulario.addField({ id: 'custpage_lblclientedireccion', type: _serverWidget.FieldType.TEXTAREA, label: 'Direccion: ', container: 'custpage_grupodatosremitente' })

                    clienteOC.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    rfcClienteOC.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    razonSocialClienteOC.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    direccionClienteOC.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    //==========================================================================

                    //======================Total mercancias=======================================
                    // let totalMercancias = formulario.addFieldGroup({id: 'custpage_grupototalmercancias',label: 'Total mercancias'});
                    // let totalPesoBruto = formulario.addField({id: 'custpage_lblpesobruto',type: _serverWidget.FieldType.TEXT,label: 'Total Peso Bruto: ',container: 'custpage_grupototalmercancias' })
                    // let totalPesoNeto = formulario.addField({id: 'custpage_lblclientedireccion',type: _serverWidget.FieldType.TEXTAREA,label: 'Direccion: ',container: 'custpage_grupototalmercancias'})
                    // let noTotalMercancias = formulario.addField({id: 'custpage_lblclientedireccion',type: _serverWidget.FieldType.TEXTAREA,label: 'Direccion: ',container: 'custpage_grupototalmercancias'})


                    //==================================ESCALAS=====================================================
                    let grupoEscalas = formulario.addFieldGroup({ id: 'custpage_escalas', label: 'Ubicación - Escalas' })
                    let sublistEscalas = formulario.addSublist({ id: 'custpage_datos_escalas', label: 'Ubicación - Escalas', type: _serverWidget.SublistType.INLINEEDITOR, container: 'custpage_escalas' });
                    let tipoUbicacion = sublistEscalas.addField({ id: 'custpage_lbl_tipo_ubicacion_escalas', type: _serverWidget.FieldType.SELECT, label: 'Tipo Ubicacion' });
                    let proveedor = sublistEscalas.addField({ id: 'custpage_lbl_tipo_proveedor_escalas', type: _serverWidget.FieldType.SELECT, label: 'Nombre', source: search.Type.VENDOR });
                    let rfc = sublistEscalas.addField({ id: 'custpage_lbl_rfc_escalas', type: _serverWidget.FieldType.TEXT, label: 'RFC' });
                    let nombre = sublistEscalas.addField({ id: 'custpage_lbl_nombre_escalas', type: _serverWidget.FieldType.TEXT, label: 'Nombre' });
                    let calle = sublistEscalas.addField({ id: 'custpage_lbl_calle_escalas', type: _serverWidget.FieldType.TEXT, label: 'Calle' });
                    var ext = sublistEscalas.addField({ id: 'custpage_lbl_ext_escalas', type: _serverWidget.FieldType.TEXT, label: '#Ext' });
                    var int = sublistEscalas.addField({ id: 'custpage_lbl_int_escalas', type: _serverWidget.FieldType.TEXT, label: '#Int' });
                    var codigoPostal = sublistEscalas.addField({ id: 'custpage_lbl_codpostal_escalas', type: _serverWidget.FieldType.TEXT, label: 'CP' });

                    var pais_fld = sublistEscalas.addField({ id: 'custpage_lbl_pais_escalas', type: _serverWidget.FieldType.SELECT, label: 'País', source: 'customrecord_efx_fe_sat_pais' });
                    var estado = sublistEscalas.addField({ id: 'custpage_lbl_estado_escalas', type: _serverWidget.FieldType.SELECT, label: 'Estado', source: 'customrecord_efx_fe_sat_estado' });
                    var municipio = sublistEscalas.addField({ id: 'custpage_lbl_municipio_escalas', type: _serverWidget.FieldType.SELECT, label: 'Mun.', source: 'customrecord_efx_fe_sat_municipio' });
                    var localidad = sublistEscalas.addField({ id: 'custpage_lbl_localidad_escalas', type: _serverWidget.FieldType.SELECT, label: 'Loc.', source: 'customrecord_efx_fe_sat_localidad' });
                    var colonia = sublistEscalas.addField({ id: 'custpage_lbl_colonia_escalas', type: _serverWidget.FieldType.SELECT, label: 'Col.', source: 'customrecord_efx_fe_sat_colonia' });

                    nombre.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    rfc.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });

                    //===========================================================================================

                    //===========================DATOS DE LA MERCANCIA========================================================
                    let grupoTotales = formulario.addFieldGroup({ id: 'custpage_totales', label: 'Mercancía - Totales' })
                    let grupoArticulos = formulario.addFieldGroup({ id: 'custpage_articulos', label: 'Mercancía - Artículos' })
                    var sublistMercancia = formulario.addSublist({ id: 'custpage_datos_mercancia', label: 'DATOS DE LA MERCANCIA', type: _serverWidget.SublistType.INLINEEDITOR, container: 'custpage_articulos' });
                    var idLine = sublistMercancia.addField({ id: 'custpage_lbl_bienes_line_id', type: _serverWidget.FieldType.TEXT, label: 'ID LINE' });
                    var bienes = sublistMercancia.addField({ id: 'custpage_lbl_bienes', type: _serverWidget.FieldType.SELECT, label: 'Bienes' });
                    var nombreBien = sublistMercancia.addField({ id: 'custpage_lbl_bienes_nombre', type: _serverWidget.FieldType.TEXT, label: 'Bienes' });

                    //====================Campos de la clave SAT==================================================
                    var satBienId = sublistMercancia.addField({ id: 'custpage_lbl_bienes_sat', type: _serverWidget.FieldType.TEXT, label: 'Bienes SAT' });
                    var satBienCod = sublistMercancia.addField({ id: 'custpage_lbl_bienes_cod_sat', type: _serverWidget.FieldType.TEXT, label: 'Clave SAT' });
                    var nombreSatBien = sublistMercancia.addField({ id: 'custpage_lbl_bienes_nombre_sat', type: _serverWidget.FieldType.TEXT, label: 'Bienes SAT' });
                    var descripcion = sublistMercancia.addField({ id: 'custpage_lbl_descripcion', type: _serverWidget.FieldType.TEXT, label: 'Descripción' });
                    var cantidad = sublistMercancia.addField({ id: 'custpage_lbl_cantidad', type: _serverWidget.FieldType.TEXT, label: 'Cantidad' });
                    var unidad = sublistMercancia.addField({ id: 'custpage_lbl_unidad', type: _serverWidget.FieldType.SELECT, label: 'Unidad', source: 'customrecord_mx_sat_unit_code' });
                    var unidadNombre = sublistMercancia.addField({ id: 'custpage_lbl_unidad_hidden', type: _serverWidget.FieldType.TEXT, label: 'Nombre Unidad' });

                    var peso = sublistMercancia.addField({ id: 'custpage_lbl_peso', type: _serverWidget.FieldType.TEXT, label: 'Peso' });
                    var pesoBruto = sublistMercancia.addField({ id: 'custpage_lbl_peso_bruto', type: _serverWidget.FieldType.TEXT, label: 'Peso bruto (KGM)' });
                    var pesoNeto = sublistMercancia.addField({ id: 'custpage_lbl_peso_neto', type: _serverWidget.FieldType.TEXT, label: 'Peso neto (KGM)' });

                    var matPeligroso = sublistMercancia.addField({ id: 'custpage_lbl_mat_peligroso', type: _serverWidget.FieldType.SELECT, label: 'Mat. Peligroso' });
                    var CveMatPeligroso = sublistMercancia.addField({ id: 'custpage_lbl_cve_mat_peligroso', type: _serverWidget.FieldType.TEXT, label: 'CveMatPeligroso' });
                    var CveMatPeligrosoHidden = sublistMercancia.addField({ id: 'custpage_lbl_cve_mat_peligroso_hidden', type: _serverWidget.FieldType.TEXT, label: 'CveMatPeligroso' });
                    CveMatPeligroso.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    CveMatPeligrosoHidden.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });

                    var flagMaterialPeligroso = sublistMercancia.addField({ id: 'custpage_lbl_flag_mat_peligroso', type: _serverWidget.FieldType.CHECKBOX, label: 'flagMatPeligroso' });
                    var embalaje = sublistMercancia.addField({ id: 'custpage_lbl_embalaje', type: _serverWidget.FieldType.SELECT, label: 'Embalaje', source: 'customrecord_efx_fe_cp_tipoembalaje' });
                    var embalajeHidden = sublistMercancia.addField({ id: 'custpage_lbl_embalaje_hidden', type: _serverWidget.FieldType.TEXT, label: 'Embalaje Nombre' });

                    var moneda = sublistMercancia.addField({ id: 'custpage_lbl_moneda', type: _serverWidget.FieldType.SELECT, label: 'Moneda', source: 'currency' });
                    var monedaNombre = sublistMercancia.addField({ id: 'custpage_lbl_moneda_hidden', type: _serverWidget.FieldType.TEXT, label: 'Moneda' });
                    var valorMercancia = sublistMercancia.addField({ id: 'custpage_lbl_valor_mercancia', type: _serverWidget.FieldType.TEXT, label: 'Val.Mercancia' });

                    var fraccionArancelaria = sublistMercancia.addField({ id: 'custpage_lbl_fraccion_arancelaria', type: _serverWidget.FieldType.SELECT, label: 'Fracción arancelaria', source: 'customrecord_efx_fe_arancelaria' });
                    var fraccionArancelariaNombre = sublistMercancia.addField({ id: 'custpage_lbl_fraccion_arancelaria_nombre', type: _serverWidget.FieldType.TEXT, label: 'Fracción arancelaria' });

                    var pedimento = sublistMercancia.addField({ id: 'custpage_lbl_pedimento', type: _serverWidget.FieldType.TEXT, label: 'Pedimento' });
                    var factura = sublistMercancia.addField({ id: 'custpage_lbl_factura', type: _serverWidget.FieldType.TEXT, label: 'Factura' });
                    var transp_int = sublistMercancia.addField({ id: 'custpage_lbl_transp_int', type: _serverWidget.FieldType.CHECKBOX, label: 'Transporte Internacional' });
                    var ent_sal_mercancia = sublistMercancia.addField({ id: 'custpage_lbl_ent_sal_merc', type: _serverWidget.FieldType.SELECT, label: 'Entrada/Salida Merc.' });
                    var paisOrigDest = sublistMercancia.addField({ id: 'custpage_lbl_pais_orig_dest', type: _serverWidget.FieldType.SELECT, label: 'Pais origen/destino..', source: 'customrecord_efx_fe_sat_pais' });
                    var totalDistancia = sublistMercancia.addField({ id: 'custpage_lbl_total_distancia', type: _serverWidget.FieldType.TEXT, label: 'Total Distancia' });


                    // var pesoBruto = sublistMercancia.addField({id: 'custpage_lbl_peso_bruto',type:_serverWidget.FieldType.TEXT,label: 'Peso bruto'});
                    // var pesoNeto = sublistMercancia.addField({id: 'custpage_lbl_peso_neto',type:_serverWidget.FieldType.TEXT,label: 'Peso neto'});
                    // pesoBruto.updateDisplayType({displayType: _serverWidget.FieldDisplayType.HIDDEN});
                    // pesoNeto.updateDisplayType({displayType: _serverWidget.FieldDisplayType.HIDDEN});
                    peso.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    idLine.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    unidadNombre.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    satBienCod.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    nombreBien.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    satBienId.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    nombreSatBien.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    descripcion.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.DISABLED });
                    flagMaterialPeligroso.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    embalajeHidden.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    monedaNombre.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });
                    fraccionArancelariaNombre.updateDisplayType({ displayType: _serverWidget.FieldDisplayType.HIDDEN });

                    //============================================================================================

                    bienes.addSelectOption({ value: '', text: '' });
                    ent_sal_mercancia.addSelectOption({ value: '', text: '', isSelected: true });
                    ent_sal_mercancia.addSelectOption({ value: 'entrada', text: 'entrada' });
                    ent_sal_mercancia.addSelectOption({ value: 'salida', text: 'salida' });

                    matPeligroso.addSelectOption({ value: '', text: '', isSelected: true });
                    matPeligroso.addSelectOption({ value: 'si', text: 'si' });
                    matPeligroso.addSelectOption({ value: 'no', text: 'no' });

                    for (var i = 0; i < items.length; i++) {
                        bienes.addSelectOption({
                            value: items[i],
                            text: itemsName[i]
                        })
                    }

                    // TODO: Grupo para Articulos
                    let grupoExtras = formulario.addFieldGroup({ id: 'custpage_extras', label: 'Extras' })

                    let btnCrearPDF = formulario.addButton({
                        id: 'custpage_tkio_generar_cart',
                        label: 'Generar Carta Porte',
                        functionName: 'generar()'
                    })

                    //========================Llenado de Sublistas========================

                    //Tipo de ubicaciones
                    tipoUbicacion.addSelectOption({ value: ' ', text: ' ' });
                    tipoUbicacion.addSelectOption({ value: 1, text: 'Origen' });
                    tipoUbicacion.addSelectOption({ value: 2, text: 'Escala' });
                    tipoUbicacion.addSelectOption({ value: 3, text: 'Destino' });


                }
                seccion = 'Renderizando el PDF'; {
                    formulario.clientScriptModulePath = _globales.cartaporte_cl
                    RES.writePage(formulario)
                }
            } catch (e) {
                log.debug(seccion, [e.name, e.message])
                log.debug({ title: 'error Onrequest: ', details: e });
                /** 
                 * Controlador de errores para suitelet
                 */
                switch (Number(e.message)) {
                    case 500:
                        /** Errores de servidor */
                        throw _error.error500
                        break;
                    case 400:
                        /** No se encontro  */
                        throw _error.error400
                        break;
                    default:
                        throw _error.errorUnknown
                        break;
                }
            }
        }

        return { onRequest }

    });

