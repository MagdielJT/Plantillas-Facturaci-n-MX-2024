/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */
define([], function() {

    function beforeLoad(context) {
        try {
            context.form.clientScriptModulePath = './actions_report.js';
            log.debug("contenido de context: ", context)
            /** Para crear el boton, se debe validar que exite una orden de compra generada.
             * Se asume que para entra a transacciones existentes los tipos de evento solo son editar y ver, con esto se valida que existe un id orden
             */
            if([context.UserEventType.EDIT,context.UserEventType.VIEW].includes(context.type)){
                var button = context.form.addButton({
                    id : 'custpage_createreport_cp',
                    label : 'Complemento - Carta Porte',
                    functionName: 'cartaComplementoSL'
                });
            }            

        } catch (e) {
            log.debug(e.name,e.message)
        }
    }



    return {
        beforeLoad: beforeLoad,

    }
});
