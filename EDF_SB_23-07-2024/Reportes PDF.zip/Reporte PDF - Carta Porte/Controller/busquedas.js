/**
 * @NApiVersion 2.1
 */
define(['N/search'],
   /**
* @param{search} search
*/
   (search) => {

      /**Búsqueda guardada que me traerá todos los países*/
      const pais = () => {
         try {
            var customrecord_efx_fe_sat_paisSearchObj = search.create({
               type: "customrecord_efx_fe_sat_pais",
               filters:
                  [
                  ],
               columns:
                  [
                     search.createColumn({
                        name: "name",
                        sort: search.Sort.ASC,
                        label: "Nombre"
                     }),
                     search.createColumn({ name: "scriptid", label: "ID de script" }),
                     search.createColumn({ name: "custrecord_efx_fe_sp_cod_sat", label: "EFX FE - SP CODIGO SAT" }),
                     search.createColumn({name: "internalid", label: "ID interno"})


                  ]
            });

            var pais = new Array();
            customrecord_efx_fe_sat_paisSearchObj.run().each(function (result) {
               var paisObj = {
                  nombre: '',
                  scriptId: '',
                  codigoSat: '',
                  idInterno: ''
               }
               paisObj.nombre = result.getValue({ name: 'name' });
               paisObj.scriptId = result.getValue({ name: 'scriptid' });
               paisObj.codigoSat = result.getValue({ name: 'custrecord_efx_fe_sp_cod_sat' });
               paisObj.idInterno = result.getValue({ name: 'internalid' });

               pais.push(paisObj);
               return true;
            });
            return pais;
         } catch (e) {
            log.error({ title: 'pais: ', details: e });
            return [];
         }
      }

      /**Búsqueda que servirá para traer relacionado el país y el estado */
      const pais_estado = (pais) => {
         try {
            var customrecord_efx_fe_sat_estadoSearchObj = search.create({
               type: "customrecord_efx_fe_sat_estado",
               filters:
                  [
                     ["custrecord_efx_fe_se_pais_ns","anyof",pais]
                  ],
               columns:
                  [
                     search.createColumn({
                        name: "name",
                        sort: search.Sort.ASC,
                        label: "Nombre"
                     }),
                     search.createColumn({ name: "scriptid", label: "ID de script" }),
                     search.createColumn({ name: "custrecord_efx_fe_se_cod_sat", label: "EFX FE - SE CODIGO SAT" }),
                     search.createColumn({ name: "custrecord_efx_fe_se_pais_ns", label: "EFX FE - SE PAIS NETSUITE" }),
                     search.createColumn({name: "internalid", label: "ID interno"})
                  ]
            });
            var paises = new Array();
            customrecord_efx_fe_sat_estadoSearchObj.run().each(function (result) {

               var paisesObj = {
                  nombre: '',
                  scriptId: '',
                  codigoSat: '',
                  paisNetsuite: '',
                  idInterno:''
               }
               paisesObj.nombre = result.getValue({ name: 'name' });
               paisesObj.scriptId = result.getValue({ name: 'scriptid' });
               paisesObj.codigoSat = result.getValue({ name: 'custrecord_efx_fe_se_cod_sat' });
               paisesObj.paisNetsuite = result.getValue({ name: 'custrecord_efx_fe_se_pais_ns' });
               paisesObj.idInterno = result.getValue({ name: 'internalid' });

               paises.push(paisesObj);
               return true;
            });
            log.debug({ title: 'paises: ', details: paises });
            return paises;
         }
         catch (e) {
            log.error({ title: 'pais_estado: ', details: e });
            return [];

         }
      }

      const municipio = (estado) => {
         try {
            var customrecord_efx_fe_sat_municipioSearchObj = search.create({
               type: "customrecord_efx_fe_sat_municipio",
               filters:
                  [
                     ["custrecord_efx_fe_csm_estadp", "anyof", "66"]
                  ],
               columns:
                  [
                     search.createColumn({
                        name: "name",
                        sort: search.Sort.ASC,
                        label: "Nombre"
                     }),
                     search.createColumn({ name: "scriptid", label: "ID de script" }),
                     search.createColumn({ name: "custrecord_efx_fe_csm_cod_sat", label: "EFX FE - SM CODIGO SAT" }),
                     search.createColumn({ name: "custrecord_efx_fe_csm_estadp", label: "EFX FE - SM ESTADO" }),
                     search.createColumn({name: "internalid", label: "ID interno"})
                  ]
            });

            var municipios = new Array();
            customrecord_efx_fe_sat_municipioSearchObj.run().each(function (result) {
               var municipiosObj = {
                  nombre: '',
                  scriptId: '',
                  codigoSat: '',
                  estado: '',
                  idInterno: ''
               }
               municipiosObj.nombre = result.getValue({ name: 'name' });
               municipiosObj.scriptId = result.getValue({ name: 'scriptid' });
               municipiosObj.codigoSat = result.getValue({ name: 'custrecord_efx_fe_csm_cod_sat' });
               municipiosObj.estado = result.getValue({ name: 'custrecord_efx_fe_csm_estadp' });
               municipiosObj.idInterno = result.getValue({ name: 'internalid' });


               municipios.push(municipiosObj);
               return true;
            });
            log.debug({ title: 'paises: ', details: municipios });
            return municipios;

         } catch (e) {
            log.error({ title: 'pais: ', details: e });
            return [];
         }

      }

      const localidad = (estado) =>{
         try{
            var customrecord_efx_fe_sat_localidadSearchObj = search.create({
               type: "customrecord_efx_fe_sat_localidad",
               filters:
               [
                  ["custrecord_efx_fe_sl_estado","anyof","66"]
               ],
               columns:
               [
                  search.createColumn({
                     name: "name",
                     sort: search.Sort.ASC,
                     label: "Nombre"
                  }),
                  search.createColumn({name: "scriptid", label: "ID de script"}),
                  search.createColumn({name: "custrecord_efx_fe_sl_cod_sat", label: "EFX FE - SL CODIGO SAT"}),
                  search.createColumn({name: "custrecord_efx_fe_sl_estado", label: "EFX FE - SL ESTADO"})
               ]
            });
            var localidades = new Array();
            customrecord_efx_fe_sat_localidadSearchObj.run().each(function (result) {
               var localidadesObj = {
                  nombre: '',
                  scriptId: '',
                  codigoSat: '',
                  estado: ''
               }
               localidadesObj.nombre = result.getValue({ name: 'name' });
               localidadesObj.scriptId = result.getValue({ name: 'scriptid' });
               localidadesObj.codigoSat = result.getValue({ name: 'custrecord_efx_fe_sl_cod_sat' });
               localidadesObj.estado = result.getValue({ name: 'custrecord_efx_fe_sl_estado' });


               localidades.push(localidadesObj);
               return true;
            });
            log.debug({ title: 'paises: ', details: municipios });
            return municipios;
            
         }catch(e){
            log.debug({title:'localidad: ',details: e});
            return [];
         }
      }
      return { pais, pais_estado, municipio,localidad}
   });
