/**
 * @NApiVersion 2.1
 */
define(['./constantes.js'],
    
    (constantes) => {

        const cabecera = (cabecera) => {
            try {
                return `<table align="left" border="0" cellpadding="1" cellspacing="1" style="width:50%">
                            <tr>
                                <td style="width:100%">&nbsp;</td>
                            </tr>
                            <tr style="height:20px">
                                <td align="center" style="height:25px; width:50%; background-color: #002060; font-size: 15pt;"><strong style="color: #ffffff;">DATOS DEL CLIENTE</strong></td>
                                <td style="width:50%" colspan="2">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="width:50%; font-size: 11pt;"><strong>Cliente:</strong> ${cabecera.subsidiaria.nombre??''}</td>
                            </tr>
                            <tr>
                                <td style="width:50%; font-size: 11pt;"><strong>RFC:</strong> ${cabecera.rfc??''}</td>
                            </tr>
                            <tr>
                                <td style="width:50%; font-size: 11pt;"><strong>Direcci&oacute;n:</strong> ${cabecera.direccion??''}</td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr style="height:20px">
                                <td align="center" style="height:25px; width:50%; background-color: #1F497D;font-size: 15pt;"><strong style="color: #ffffff;">DATOS DE LA MERCANCIA</strong></td>
                                <td style="width:50%" colspan="2">&nbsp;</td>
                            </tr>
                        </table>`
            } catch (e) {
                log.debug("❌Error en logo",e)
                
            }
        }


        const totalMateriales = (totalMercancia) =>{
            try{
            return `    <table align="left" border="0" cellpadding="1" cellspacing="1" style="width:50%; margin-top:20px">
                        <tr style="background-color: #F15905;">
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff; text-align:center;">Número total de mercancias</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff; margin-right:50px; text-align:center;">Peso Bruto Total</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff; margin-right:15px; text-align:center;">Clave Unidad Peso</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;text-align:center;">Peso Neto Total (KGM)</p></th>
                            
                        </tr>
            
            
                        <tr>

                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-left:25px;">${totalMercancia.noTotalMercancias}</th>
                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-left:25px;">${totalMercancia.totalBruto}</th>
                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-left:25px;">${'kgs'}</th>
                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-left:25px;">${totalMercancia.totalNeto}</th>
                    
            
                        </tr>
                        </table>
                    `
            }catch(e){
                log.debug({title: 'totalMateriales', details: totalMateriales});
            }
        }


        const mercancias = (material) => {
            try {
                let conjuntoPrincipal = ''
                let conjuntoFinanciero = ''
                let conjuntoUbicacion = ''
                material.map((cadaMaterial) => {
                    conjuntoPrincipal += `<tr>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-right:15px">${cadaMaterial.material.nombre??''}</th>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px;">${cadaMaterial.descripcion??''}</th>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-left:15px">${cadaMaterial.cantidad??''}</th>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px;">${cadaMaterial.unidad.nombre??''}</th>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px;">${cadaMaterial.peso??''}</th>
                                            <th colspan="1" style="font-size: 8pt;padding: 2px; margin-right:15px">${cadaMaterial.clvmaterialpeligroso.nombre??''}</th>
                                            <th colspan="2" style="font-size: 8pt;padding: 2px; margin-right:10px">${cadaMaterial.ensamble.nombre??''}</th>
                                            
                                        </tr>`
                    
                        conjuntoFinanciero += `<tr>
                                           <th colspan="1" style="font-size: 9pt;padding: 0px;">${cadaMaterial.fraccionarancelaria??''}</th>
                                           <th colspan="1" style="font-size: 9pt;padding: 0px;">${cadaMaterial.pedimento??''}</th>
                                           <td colspan="3" style="font-size: 11pt;">${cadaMaterial.factura.nombre}</td>
                                           <td colspan="3" style="font-size: 11pt;">${cadaMaterial.valormercancia}</td>
                                           <td colspan="4" style="font-size: 11pt;">${cadaMaterial.moneda.nombre}</td>
                                       </tr>
                                       <tr><td colspan="10">&nbsp;</td></tr>`
                        conjuntoUbicacion += `<tr>
                                           <td colspan="2" style="font-size: 11pt;">${cadaMaterial.transporteinternacional?'Sí':'No'}</td>
                                           <td colspan="2" style="font-size: 11pt;">${cadaMaterial.entradasalidamerc.nombre}</td>
                                           <td colspan="3" style="font-size: 11pt;">${cadaMaterial.paisorigen.nombre}</td>
                                           <td colspan="3" style="font-size: 11pt;">${cadaMaterial.totaldistancia}</td>
                                       </tr>
                                       <tr><td colspan="10">&nbsp;</td></tr>`
                     
                })
                return `<tr style="background-color: #1F497D;">
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Bienes</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff; margin-right:50px">Descripci&oacute;n</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff; margin-right:15px">Cantidad</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Unidad</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Peso</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Clv. material</p></th>
                            
                            <th colspan="2" style="font-size: 9pt;"><p style="color: #ffffff;">Embalaje</p></th>
                            
                        </tr>
                        <tr>
                            <td colspan="11">&nbsp;</td>
                        </tr>
                        ${conjuntoPrincipal}
                            <tr style="background-color: #1F497D; ">
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Frac. arancelar&iacute;a</p></th>
                            <th colspan="1" style="font-size: 9pt;"><p style="color: #ffffff;">Pedimento</p></th>
                            <th colspan="3"><p style="color: #ffffff;">Factura</p></th>
                            <th colspan="3"><p style="color: #ffffff;">Valor Mercanc&iacute;a</p></th>
                            <th colspan="4"><p style="color: #ffffff; margin-right:15px">Moneda</p></th>

                        </tr>
                        <tr>
                            <td colspan="10">&nbsp;</td>
                        </tr>
                        ${conjuntoFinanciero}
                        <tr style="background-color: #1F497D; color: #ffffff;">
                            <th colspan="2" style="font-size: 9pt;" aling="center"><p style="color: #ffffff;">Transporte Internacional</p></th>
                            <th colspan="2" style="font-size: 9pt;" ><p style="color: #ffffff;">Entrada/Saldida Mercanc&iacute;a</p></th>
                            <th colspan="3" style="font-size: 9pt;" ><p style="color: #ffffff;">Pa&iacute;s origen/destino</p></th>
                            <th colspan="3" style="font-size: 9pt;" ><p style="color: #ffffff;">Total de Distancia</p></th>
                        </tr>
                        <tr>
                            <td colspan="10">&nbsp;</td>
                        </tr>
                        ${conjuntoUbicacion}`
            } catch (e) {
                log.debug("❌Error en logo",e)
                
            }
        }

        const origen_destino_escala = (escalas) => {
            try {
                let opcion = constantes.ENUMS.ORIGEN
                switch (opcion) {
                    case constantes.ENUMS.ORIGEN:
                        break;
                    case constantes.ENUMS.DESTINO:
                        break;
                    default:
                        break;
                }
                let conjunto = '';
                let conjuntoAux ='';
                escalas.map(cadaDestino => {

                    conjunto += `
                                <tr style="background-color: #F15905; color: #ffffff;">
                                    <td colspan="3"><p style="color: #ffffff;">Tipo Ubicaci&oacute;n</p></td>
                                    <td colspan="2"><p style="color: #ffffff;">RFC</p></td>
                                    <td colspan="5"><p style="color: #ffffff;">Nombre</p></td>
                                </tr>
                                <tr>
                                    <td colspan="3">${cadaDestino.tipoubicacion.nombre}</td>
                                    <td colspan="2">${cadaDestino.rfc}</td>
                                    <td colspan="5">${cadaDestino.nombre}</td>
                                </tr>           
                                
                                <tr style="background-color: #F15905; color: #ffffff;">
                                    <td colspan="1" style="width:25%;"><p style="color: #ffffff;">Calle</p></td>
                                    <td colspan="1" style="width:3%;"><p style="color: #ffffff;">#Ext</p></td>
                                    <td colspan="1" style="width:3%;"><p style="color: #ffffff;">#Int</p></td>
                                    <td colspan="1" style="width:19%;"><p style="color: #ffffff;">Col</p></td>
                                    <td colspan="1" style="width:19%;"><p style="color: #ffffff;">Loc</p></td>
                                    <td colspan="1" style="width:19%;"><p style="color: #ffffff;">Mun</p></td>
                                    <td colspan="1" style="width:5%;"><p style="color: #ffffff;">Estado</p></td>
                                    <td colspan="1" style="width:4%;"><p style="color: #ffffff;">Pa&iacute;s</p></td>
                                    <td colspan="1" style="width:3%;"><p style="color: #ffffff;">CP</p></td>
                                </tr>
                    
                                <tr>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.calle||''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.exterior || ''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.interior ||''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.colonia||''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.localidad||''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.municipio||''}</td>
                                    <td colspan="1" style="font-size: 11pt; margin-right: 10px" >${cadaDestino.direccion.estado||''}</td>
                                    <td colspan="1" style="font-size: 11pt;margin-right: 10px" >${cadaDestino.direccion.pais||''}</td>
                                    <td colspan="1" style="font-size: 11pt;" >${cadaDestino.direccion.cp||''}</td>
                                </tr>
                                
                                <tr>
                                    <td colspan="10"> &nbsp; </td>
                                </tr>`
                    
                })
                return conjunto;
                
            } catch (e) {
                log.debug("eer",e)
                
            }
        }
        
        const logo = (imagen) => {
            try {
                imagen = imagen.replace(/&/g, '&amp;')
                log.debug("Imagen: ", imagen)
                return `<table align="center" border="0" cellpadding="1" cellspacing="1" style="width:100%">
                            <tr style="height:25px">
                                <td style="width:50%"><img src="${  imagen }"/></td>
                                <td style="width:50%">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="width:100%">&nbsp;</td>
                            </tr>
                        </table>`
            } catch (e) {
                log.debug("❌Error en logo",e)
            }
        }
        
        const plantillaPDF = (datos) => {
            try {
                
                return `<?xml version="1.0"?><!DOCTYPE pdf PUBLIC "-//big.faceless.org//report" "report-1.1.dtd">
                        <pdf>
                            <head>
                                <macrolist>
                                    <macro id="nlheader">
                                        <p><totalpages/></p>
                                    </macro>
                                    <macro id="nlfooter">
                                        <p>&nbsp;</p>
                                    </macro>
                                </macrolist>
                            </head>
                            <body footer="nlfooter" footer-height="20pt" padding="0.5in 0.5in 0.5in 0.5in" size="Letter">
                                ${ logo(datos.imagen) }
                                <table align="center" border="0" cellpadding="1" cellspacing="1" style="width:100%">
                                    <tr style="height:25px">
                                        <td style="width:100%; background-color:#E1E1E1;" align="center"><strong>COMPLEMENTO CARTA PORTE AUTOTRANSPORTE V2.0</strong></td>
                                    </tr>
                                    <tr>
                                        <td style="width:100%">&nbsp;</td>
                                    </tr>
                                </table>
                                ${ cabecera(datos.cabecera) }     
                                ${totalMateriales(datos.totalMateriales)}      
                                <table border="0" cellpadding="1" cellspacing="1" style="width:100%">
                                    <tr>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                    </tr>
                                    
                                </table>
                                <table align="center" border="0" cellpadding="1" cellspacing="1" style="width:100%">
                                
                                ${mercancias(datos.material)}
                                ${origen_destino_escala(datos.escalas)}
                                </table>
                            </body>
                        </pdf>`
            } catch (e) {
                log.debug("❌Error en logo",e)
            }
        }

        return {plantillaPDF}

    });
