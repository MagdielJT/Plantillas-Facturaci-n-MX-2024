/**
 * @NApiVersion 2.1
 */
define([],
    
    () => {
        return {
            ENUMS: Object.freeze({
                ORIGEN: "origen",
                DESTINO : "destino"
            })
        }
    });
