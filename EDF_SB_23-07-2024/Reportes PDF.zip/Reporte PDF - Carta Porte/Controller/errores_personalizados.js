/**
 * @NApiVersion 2.1
 */
define(['N/error'],
    /**
 * @param{error} error
 */
    (_error) => {

        return {
            error500 : _error.create({
                name : 'Error de tipo',
                message : 'Error de servidor Ejemplo',
                notifyOff : true
            }),
            error400 : _error.create({
                name : 'NO_ID',
                message : 'Orden de compra no encontrada',
                notifyOff : true
            }),
            errorUnknown : _error.create({
                name : 'Error_Desconocido',
                message : 'Error de Netsuite no conocido',
                notifyOff : true
            })
        }

    });
