/**
 * @NApiVersion 2.1
 */
define(['N/ui/message'],
    /**
 * @param{message} message
 */
    (message) => {
        /**
        * Lista de errores comunes.
        */
        const errores = Object.freeze(
            {
                ERIDORDEN : "error_falta_id_orden_compra",
                "ERROR" : message.Type.ERROR
            }
        )
        const mensajeParaClientes = (caso,info) => {
            let seccion = ''
            log.debug("--------","mensajeParaClientes")
            log.debug(caso,info)
            try {
                seccion = 'Carga de mensajes globales';{
                    let msg = message.create({ title: info.titulo, message: info.texto, type: errores[info.tipo]})
                    switch (caso) {
                        case errores.ERIDORDEN:
                            if (info.hasOwnProperty('tiempo')) {
                                msg.show({
                                    duration: info.tiempo
                                });
                            } else {
                                msg.show();
                            }
                            break;
                    
                        default:
                            break;
                    }
                }
            } catch (e) {
                log.debug(seccion, `${e.name} ---- ${e.mensaje}`)
            }
        }

        return {mensajeParaClientes}

    });
