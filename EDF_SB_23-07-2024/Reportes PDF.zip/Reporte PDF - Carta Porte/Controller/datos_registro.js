/**
 * @NApiVersion 2.1
 */
define(['N/record', 'N/search', './busquedas.js'],
    /**
 * @param{record} record
 */
    (record, search, busquedas) => {

        const cargarOrdenDeCompra = (idRegistro) => {

            log.debug("Datos de record :")
            try {
                log.debug("Id de registro: 🤔", idRegistro)
                let registrOrdenDecompra = record.load({
                    type: record.Type.PURCHASE_ORDER,
                    id: idRegistro,
                    isDynamic: false
                })
                let campos = registrOrdenDecompra.getFields();
                log.debug({ title: 'campos: ', details: campos });
                // log.debug( "getSublistFields", registrOrdenDecompra.getSublistFields({sublistId: 'item'}))

                /**Datos de la subsidiaria */
                let shippAddress = registrOrdenDecompra.getValue({ fieldId: 'shipaddress' });
                let subsidiaria = registrOrdenDecompra.getValue({ fieldId: 'subsidiary' });

                /**Datos del proveedor. */
                var proveedor = registrOrdenDecompra.getValue({ fieldId: 'entity' });
                // log.debug({title: 'proveedor', details: proveedor});

                var proveedorDatos = search.lookupFields({
                    type: search.Type.VENDOR,
                    id: proveedor,
                    columns: ['companyname', 'custentity_mx_rfc', 'legalname', 'address']
                });
                log.debug({ title: 'proveedorDatos', details: proveedorDatos });

                var subsidiariaDatos = search.lookupFields({
                    type: search.Type.SUBSIDIARY,
                    id: subsidiaria.toString(),
                    columns: ['name', 'taxidnum', 'legalname', 'internalid']
                });

                //==============Datos =========================
                var subsidiariaDatos = search.lookupFields({
                    type: search.Type.SUBSIDIARY,
                    id: subsidiaria.toString(),
                    columns: ['name', 'taxidnum', 'legalname', 'internalid']
                });

                let nombreOrdenCompra = registrOrdenDecompra.getValue({ fieldId: 'tranid' });
                let creacionOrden = registrOrdenDecompra.getValue({ fieldId: 'createddate' });
                let recordcreatedate = registrOrdenDecompra.getValue({ fieldId: 'recordcreateddate' });
                let fechaCompra = registrOrdenDecompra.getValue({ fieldId: 'trandate' });
                let entregaOrden = registrOrdenDecompra.getValue({ fieldId: 'duedate' });
                let statusId = registrOrdenDecompra.getValue({ fieldId: 'approvalstatus' });
                let status = registrOrdenDecompra.getValue({ fieldId: 'status' });
                let numCliente = registrOrdenDecompra.getValue({ fieldId: 'otherrefnum' });


                let subsidiaria_data = { id: subsidiariaDatos.internalid[0].value, nombre: subsidiariaDatos.name }
                let objProveedor = { id: proveedor, nombre: proveedorDatos.companyname }
                let objOrdenCompra = { id: idRegistro, nombre: nombreOrdenCompra }
                let objStatusApproval = { id: statusId, nombre: status }

                let objSubsidiaria = {
                    objRecord: registrOrdenDecompra,
                    subsidiaria: subsidiaria_data,
                    rfc: subsidiariaDatos.taxidnum,
                    razon_social: subsidiariaDatos.legalname,
                    proveedor: objProveedor,
                    ordenCompra: objOrdenCompra,
                    numeropedido: nombreOrdenCompra,
                    fechaentrega: entregaOrden,
                    fechacompra: fechaCompra,
                    estadoaprobacion: objStatusApproval,
                    direccion: shippAddress,
                    creacionregistro: recordcreatedate,
                    cliente: numCliente

                }

                log.debug({ title: 'objSubsidiaria: ', details: JSON.stringify(objSubsidiaria) });

                // var fileObj = file.create({
                //     name    : 'datosDelRegistro.json',
                //     fileType: file.Type.JSON,
                //     contents: JSON.stringify(registrOrdenDecompra)
                // });
                // fileObj.folder = 276900;
                // var fileId = fileObj.save();    
                return objSubsidiaria;
            } catch (e) {
                log.debug(`👀 ${e.name}`, e.message)
                return { error: e.name, mensaje: e.message }
            }
        }

        const datosDeEfx_fe_sat = () => {
            try {
                // paises=  busquedas.pais_estado();
                // // var pais = busquedas.pais_estado();
                // log.debug({title:'pais_estado: ',details:paises}); 
            } catch (e) {
                log.debug(`👀 ${e.name}`, e.message)
            }
        }

        /** Manejo de datos PDF */

        const cartaporte = (idOrdenCompra) => {
            try {
                let cartaPorte = {
                    cabecera: {},
                    material: [],
                    escalas: [],
                    totalMateriales: {}
                }
                let listaBusquedaBienes = []
                let listaBusquedaEscalas = []
                let complementoCartaPorte = cartaPorteRP(idOrdenCompra)
                complementoCartaPorte.run().each(function (elementoCartaPorte) {
                    log.debug("cada resultadoCarta porte: ", elementoCartaPorte)
                    listaBusquedaBienes = elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_materiales_cp' })
                    listaBusquedaEscalas = elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_escalas_cp' })
                    // let direccion = JSON.parse(elementoCartaPorte.getValue({'name': 'custrecord_tkio_direccioncompuesta_cp'}))
                    let direccion = elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_direccioncompuesta_cp' })
                    cartaPorte.cabecera = {
                        id: elementoCartaPorte.id,
                        subsidiaria: {
                            id: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_subsidiaria_cp' }),
                            nombre: elementoCartaPorte.getText({ 'name': 'custrecord_tkio_subsidiaria_cp' })
                        },
                        razonsocial: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_razonsocial_cp' }),
                        rfc: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_rfccliente_cp' }),
                        proveedor: {
                            id: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_proveedor_cp' }),
                            nombre: elementoCartaPorte.getText({ 'name': 'custrecord_tkio_proveedor_cp' })
                        },
                        // extras:JSON.parse(elementoCartaPorte.getValue({'name':'custrecord_tkio_otrosdatos_cp'}) ),
                        ordencompra: {
                            id: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_idordendecomprar_cp' }),
                            nombre: elementoCartaPorte.getText({ 'name': 'custrecord_tkio_idordendecomprar_cp' })
                        },
                        numeropedido: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_numeropedido_cp' }),
                        fechaentrega: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_fechaprevistaentrega_cp' }),
                        fechacompra: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_fechacompra_cp' }),
                        estadoaprobacion: {
                            id: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_estadoaprobacion_cp' }),
                            nombre: elementoCartaPorte.getText({ 'name': 'custrecord_tkio_estadoaprobacion_cp' })
                        },

                        direccion: direccion,
                        creacionregistro: elementoCartaPorte.getValue({ 'name': 'created' }),
                        cliente: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_clientecompra_cp' })
                    };

                    cartaPorte.totalMateriales = {
                        noTotalMercancias: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_totaldemercancias' }),
                        totalBruto: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_totalpesobruto' }),
                        totalNeto: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_totalpesoneto' }),
                        claveUnidad: elementoCartaPorte.getValue({ 'name': 'custrecord_tkio_claveunidadpeso' }),
                    }
                    // return true
                })



                cartaPorte.material = c_bienes(listaBusquedaBienes.split(',')) ?? []
                cartaPorte.escalas = c_escalas(listaBusquedaEscalas.split(',')) ?? []

                log.debug("datos", cartaPorte)
                return cartaPorte
            } catch (e) {
                log.debug("Error en datos registros: ", [e.name, e.message])
            }
        }

        const c_bienes = (listaBusquedaBienes) => {
            try {
                let listaEscalas = []
                let complementoCPBienes = bienesRP(listaBusquedaBienes)
                complementoCPBienes.run().each(function (elementoCPBienes) {
                    // log.debug("cada resultadoCarta bienes: ", elementoCPBienes)
                    listaEscalas.push({
                        id: elementoCPBienes.id,
                        material: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_bienes_rp' }),
                            nombre: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_clavesat_rp' })
                        },
                        cantidad: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_cantidad_rp' }),
                        clvmaterialpeligroso: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_clvmaterial_rp' }),
                            nombre: elementoCPBienes.getText({ 'name': 'custrecord_tkio_clvmaterial_rp' })
                        },
                        descripcion: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_descripcion_rp' }),
                        ensamble: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_embalaje_rp' }),
                            nombre: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_embalaje_rp' })
                        },
                        entradasalidamerc: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_entradasalidamerc_rp' }),
                            nombre: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_entradasalidamerc_rp' })
                        },
                        factura: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_factura_rp' }),
                            nombre: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_factura_rp' })
                        },
                        fraccionarancelaria: elementoCPBienes.getText({ 'name': 'custrecord_tkio_fraccionarancelaria_rp' }),
                        materialpeligros: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_materialpeligroso_rp' }),
                        moneda: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_moneda_rp' }),
                            nombre: elementoCPBienes.getText({ 'name': 'custrecord_tkio_moneda_rp' })
                        },
                        paisorigen: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_paisorigendest_rp' }),
                            nombre: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_paisorigendest_rp' })
                        },
                        pedimento: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_pedimento_rp' }),
                        peso: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_peso_neto_rp' }),
                        totaldistancia: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_totaldistacia_rp' }),
                        transporteinternacional: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_transportinternacnl_rp' }),
                        unidad: {
                            id: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_unidad_rp' }),
                            nombre: elementoCPBienes.getText({ 'name': 'custrecord_tkio_unidad_rp' })
                        },
                        valormercancia: elementoCPBienes.getValue({ 'name': 'custrecord_tkio_valormercancia_rp' })
                    })
                    return true
                })
                return listaEscalas
            } catch (e) {
                log.debug("c_bienes", [e.name, e.message])
            }
        }

        const c_escalas = (listaBusquedaEscalas) => {
            try {
                let listaEscalas = []
                let complementoCPEscalas = escalasRP(listaBusquedaEscalas)
                complementoCPEscalas.run().each(function (elementoCPEscalas) {
                    // log.debug("cada resultadoCarta escalas: ", elementoCPEscalas)
                    let direccion = JSON.parse(elementoCPEscalas.getValue({ 'name': 'custrecord_tkio_calle_rp' })) ?? ''
                    listaEscalas.push({
                        id: elementoCPEscalas.id,
                        tipoubicacion: {
                            id: elementoCPEscalas.getValue({ 'name': 'custrecord_tkio_tipoubicacion_rp' }),
                            nombre: elementoCPEscalas.getText({ 'name': 'custrecord_tkio_tipoubicacion_rp' })
                        },
                        rfc: elementoCPEscalas.getValue({ 'name': 'custrecord_tkio_rfc_rp' }),
                        nombre: elementoCPEscalas.getValue({ 'name': 'custrecord_tkio_nombre_rp' }),
                        direccion: {
                            calle: direccion.calle,
                            exterior: direccion.exterior,
                            interior: direccion.interior,
                            colonia: direccion.colonia,
                            localidad: direccion.localidad,
                            municipio: direccion.municipio,
                            estado: direccion.estado,
                            pais: direccion.pais,
                            cp: direccion.cp,
                        }
                    })
                    return true
                })
                return listaEscalas
            } catch (e) {
                log.debug("c_escalas", [e.name, e.message])
            }
        }

        /** Manejo de datos PDF */

        /** Esto va en el script de busquedas */

        const cartaPorteRP = (idOrdenCompra) => {
            try {
                return search.create({
                    type: "customrecord_tkio_cartaporte_rp",
                    filters:
                        [
                            //    ["custrecord_tkio_idordendecomprar_cp",search.Operator.ANYOF,idOrdenCompra]
                            ["internalid", search.Operator.IS, idOrdenCompra]
                            //    ["custrecord_tkio_idordendecomprar_cp",search.Operator.ANYOF,"21724"]15
                        ],
                    columns:
                        [
                            search.createColumn({ name: "custrecord_tkio_subsidiaria_cp", label: "Subsidiaria" }),
                            search.createColumn({ name: "custrecord_tkio_razonsocial_cp", label: "Razon social" }),
                            search.createColumn({ name: "custrecord_tkio_rfccliente_cp", label: "RFC Cliente" }),
                            search.createColumn({ name: "custrecord_tkio_proveedor_cp", label: "Proveedor" }),
                            search.createColumn({ name: "custrecord_tkio_otrosdatos_cp", label: "Otros datos Json" }),
                            search.createColumn({ name: "custrecord_tkio_idordendecomprar_cp", label: "Orden de Compra" }),
                            search.createColumn({ name: "custrecord_tkio_materiales_cp", label: "Materiales" }),
                            search.createColumn({ name: "custrecord_tkio_numeropedido_cp", label: "Numero de pedido" }),
                            search.createColumn({ name: "custrecord_tkio_fechaprevistaentrega_cp", label: "Fecha Prevista Entrega" }),
                            search.createColumn({ name: "custrecord_tkio_fechacompra_cp", label: "Fecha Compra" }),
                            search.createColumn({ name: "custrecord_tkio_estadoaprobacion_cp", label: "Estado de aprobacion" }),
                            search.createColumn({ name: "custrecord_tkio_escalas_cp", label: "Escalas" }),
                            search.createColumn({ name: "custrecord_tkio_direccioncompuesta_cp", label: "Direccion compuesta" }),
                            search.createColumn({ name: "created", label: "Date Created" }),
                            search.createColumn({ name: "custrecord_tkio_clientecompra_cp", label: "Comprador/Cliente" }),


                            search.createColumn({ name: "custrecord_tkio_totalpesobruto", label: "Total Peso Bruto" }),
                            search.createColumn({ name: "custrecord_tkio_totalpesoneto", label: "Total Peso Neto" }),
                            search.createColumn({ name: "custrecord_tkio_totaldemercancias", label: "Total de Mercancias" }),
                            search.createColumn({ name: "custrecord_tkio_claveunidadpeso", label: "Clave Unidad Peso" })
                        ]
                })
            } catch (error) {
                log.error({ title: 'cartaPorteRP', details: e });
                return [];
            }
        }
        const escalasRP = (idEscalas) => {
            try {
                return search.create({
                    type: "customrecord_tkio_escalas_rp",
                    filters:
                        [
                            ["internalid", search.Operator.ANYOF, idEscalas]
                            //    ["internalid",search.Operator.ANYOF,"1","2","3"]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "custrecord_tkio_calle_rp", label: "Direccion" }),
                            search.createColumn({ name: "custrecord_tkio_nombre_rp", label: "Nombre" }),
                            search.createColumn({ name: "custrecord_tkio_rfc_rp", label: "RFC" }),
                            search.createColumn({ name: "custrecord_tkio_tipoubicacion_rp", label: "Tipo de ubicacion" })
                        ]
                })
            } catch (error) {
                log.error({ title: 'escalasRP', details: e });
                return [];
            }
        }
        const bienesRP = (idBienes) => {
            try {
                return search.create({
                    type: "customrecord_tkio_bienestrasportados_rp",
                    filters:
                        [
                            ["internalid", search.Operator.ANYOF, idBienes]
                            // ["internalid",search.Operator.ANYOF,"1","2"]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "custrecord_tkio_bienes_rp", label: "Bienes" }),
                            search.createColumn({ name: "custrecord_tkio_cantidad_rp", label: "Cantidad" }),
                            search.createColumn({ name: "custrecord_tkio_clvmaterial_rp", label: "Clave Material peligroso" }),
                            search.createColumn({ name: "custrecord_tkio_descripcion_rp", label: "Descripcion" }),
                            search.createColumn({ name: "custrecord_tkio_embalaje_rp", label: "Embalaje" }),
                            search.createColumn({ name: "custrecord_tkio_entradasalidamerc_rp", label: "Entrada - Salida Mercancia" }),
                            search.createColumn({ name: "custrecord_tkio_factura_rp", label: "Factura" }),
                            search.createColumn({ name: "custrecord_tkio_fraccionarancelaria_rp", label: "Fraccion arancelaria" }),
                            search.createColumn({ name: "custrecord_tkio_materialpeligroso_rp", label: "Material Peligroso" }),
                            search.createColumn({ name: "custrecord_tkio_moneda_rp", label: "Moneda" }),
                            search.createColumn({ name: "custrecord_tkio_paisorigendest_rp", label: "Pais origen - destino" }),
                            search.createColumn({ name: "custrecord_tkio_pedimento_rp", label: "Pedimento" }),
                            search.createColumn({ name: "custrecord_tkio_peso_rp", label: "Peso" }),
                            search.createColumn({ name: "custrecord_tkio_totaldistacia_rp", label: "Total distancia" }),
                            search.createColumn({ name: "custrecord_tkio_transportinternacnl_rp", label: "Transporte Internacional" }),
                            search.createColumn({ name: "custrecord_tkio_unidad_rp", label: "Unidad" }),
                            search.createColumn({ name: "custrecord_tkio_valormercancia_rp", label: "Valor mercancia" }),
                            search.createColumn({ name: "custrecord_tkio_clavesat_rp", label: "Clave SAT" }),
                            search.createColumn({ name: "custrecord_tkio_peso_neto_rp", label: "Peso Neto" })
                        ]
                })
            } catch (error) {
                log.error({ title: 'bienesRP', details: e });
                return [];
            }
        }

        /** Esto va en el script de busquedas */

        return { cargarOrdenDeCompra, datosDeEfx_fe_sat, cartaporte }

    });
