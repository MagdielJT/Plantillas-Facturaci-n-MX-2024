/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['./Controller/mensajes.js', 'N/currentRecord', './Controller/datos_registro.js', 'N/record', './Controller/busquedas', 'N/url', 'N/ui/message', 'N/search', './Controller/moment.min', 'N/format', 'N/https'],

    function (mensajes, currentRecord, datos_registros, record, busquedas, url, message, search, moment, format, https) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */

        var prodId = getParameterByName('ordenDeCompra');//Variable que ayudará a obtener valores de la URL
        var ubicaciones = new Array();//Llenado del arreglo de ubicaciones.
        var materiales = new Array(); //Arreglo para el llenado de materiales
        var objGlobal = {};//Json que servirá para almacenar todos los json
        var objUbicaciones = {};//Json de escalas
        var jsonRecord = {};//Json traido desde datos_registro
        var jsonCliente = {};//Json con la informacion del cliente
        var jsonCurrency = {};//Json para obtener currency
        var objMercancia = {};
        var items = new Array();//Array que servirá para guardar todos los items
        var fieldItem = {}//Obj global que permitira traer el item ya filtrado.
        var objtotalMercancias = {};//Obj global que almacenará el total de mercancias

        function pageInit(scriptContext) {
            try {
                jsonRecord = datos_registros.cargarOrdenDeCompra(prodId);
                console.log("jsonRecord: ", jsonRecord);
                //===============================================================================================
                const urlCadena = window.location.search;
                const urlParametros = new URLSearchParams(urlCadena);
                if (!urlParametros.has("ordenDeCompra"))
                    mensajes.mensajeParaClientes("error_falta_id_orden_compra",
                        {
                            titulo: "Registro no existe.",
                            texto: "Este ID no pertenece a una orden de compra registrada",
                            tipo: "ERROR"
                        })

                //==============================Obtener datos de la OC==============================================
                let objRecord = jsonRecord.objRecord;
                let numLines = objRecord.getLineCount({ sublistId: 'item' });

                for (let i = 0; i < numLines; i++) {
                    let idItem = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
                    let idLine = Number(objRecord.getSublistValue({ sublistId: 'item', fieldId: 'line', line: i })) - 1;
                    let nombre = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'item_display', line: i });
                    let cantidad = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
                    let descripcion = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'description', line: i });
                    let unidadesId = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'units', line: i });
                    let unidadesNombre = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'units_display', line: i });
                    let valorMercancia = objRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: i });

                    objMercancia = {
                        idLine: idLine,
                        id: idItem,
                        nombre: nombre,
                        cantidad: cantidad,
                        descripcion: descripcion,
                        unidadesId: unidadesId,
                        unidadesNombre: unidadesNombre,
                        valorMercancia: valorMercancia

                    }
                    items.push(objMercancia);
                }
                //=================================cargar datos cliente=======================================
                let fechaEntrega = moment(jsonRecord.fechaEntrega).locale('es-mx').format('YYYY/MM/DD');
                let fechaCompra = moment(jsonRecord.fechacompra).locale('es-mx').format('YYYY/MM/DD');

                jsonCliente = {
                    subsidiaria: jsonRecord.subsidiaria,
                    rfc: jsonRecord.rfc,
                    razonsocial: jsonRecord.razon_social,
                    proveedor: jsonRecord.proveedor,
                    ordencompra: jsonRecord.ordenCompra,
                    numeropedido: jsonRecord.numeropedido,
                    fechaentrega: fechaEntrega,
                    fechacompra: fechaCompra,
                    estadoaprobacion: jsonRecord.estadoaprobacion,
                    direccion: jsonRecord.direccion,
                    creacionregistro: jsonRecord.creacionregistro,
                    cliente: jsonRecord.cliente,
                }
                console.log('jsonCliente: ' + JSON.stringify(jsonCliente));
                /**Seteo de datos en la pantalla */
                var currentForm = currentRecord.get();
                /*================Seteo de datos del cliente (Proveedor) ===================== */
                currentForm.setValue({ fieldId: 'custpage_lblclientenombre', value: jsonRecord.subsidiaria.nombre });
                currentForm.setValue({ fieldId: 'custpage_lblclienterfc', value: jsonRecord.rfc });
                currentForm.setValue({ fieldId: 'custpage_lblrazonsocial', value: jsonRecord.razon_social });
                currentForm.setValue({ fieldId: 'custpage_lblclientedireccion', value: jsonRecord.direccion });

            } catch (e) {
                console.error('Page init: ', e)
            }

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            try {
                let objRecord = scriptContext.currentRecord;
                //==========================Modificación de la lista de mercancia=======================================
                if (scriptContext.sublistId == 'custpage_datos_mercancia') {
                    let item;
                    if (scriptContext.fieldId == 'custpage_lbl_bienes') {
                        item = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes' });
                        console.log('item fld change: ', item);
                        if (item !== '') {

                            items.forEach((articulo, index) => {
                                console.log('Indice: ' + index + ' Valor: ' + JSON.stringify(articulo.id));
                                if (item == articulo.idLine) {
                                    fieldItem = {
                                        idLine: articulo.idLine,
                                        id: articulo.id,
                                        nombre: articulo.nombre,
                                        cantidad: articulo.cantidad,
                                        descripcion: articulo.descripcion,
                                        unidadesId: articulo.unidadesId,
                                        unidadesNombre: articulo.unidadesNombre,
                                        valorMercancia: articulo.valorMercancia
                                    }
                                }

                            });
                            console.log('fieldItem: ' + JSON.stringify(fieldItem));

                            //===================================Busqueda de datos del articulo.======================
                            var itemDatos = search.lookupFields({
                                type: search.Type.ITEM,
                                id: fieldItem.id,
                                columns: ['custitem_efx_fe_cp_cvematpeligro', 'custitem_efx_fe_cp_embalaje', 'name', 'custitem_efx_fe_cp_materialpeligro', 'custitem_efx_fe_cp_pesokg', 'custitem_mx_txn_item_sat_item_code', 'custitem_efx_fe_ce_fracc_arancelaria', 'custitem_efx_fe_cp_pesoneto', 'custitem_efx_fe_cp_pesobruto']
                            });

                            var pesoNeto = itemDatos.custitem_efx_fe_cp_pesoneto != "" ? itemDatos.custitem_efx_fe_cp_pesoneto : 0;
                            var pesoBruto = itemDatos.custitem_efx_fe_cp_pesobruto != "" ? itemDatos.custitem_efx_fe_cp_pesobruto : 0;
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso_neto', value: pesoNeto });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso_bruto', value: pesoBruto });

                            let satId, satNombre, satCodigo;

                            if (itemDatos.custitem_mx_txn_item_sat_item_code.length != 0) {
                                var satDatos = search.lookupFields({
                                    type: 'customrecord_mx_sat_item_code',
                                    id: itemDatos.custitem_mx_txn_item_sat_item_code[0].value,
                                    columns: ['internalid', 'name', 'custrecord_mx_ic_code']
                                });
                                satId = satDatos.internalid[0].value;
                                satNombre = satDatos.name;
                                satCodigo = satDatos.custrecord_mx_ic_code;
                            } else {
                                satId = '';
                                satNombre = '';
                                satCodigo = '';
                            }

                            console.log('itemDatos', JSON.stringify(itemDatos));
                            //===========================Seteo de datos================================================
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_sat', value: satId });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_cod_sat', value: satCodigo });

                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_descripcion', value: satNombre })
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_line_id', value: fieldItem.idLine });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_flag_mat_peligroso', value: itemDatos.custitem_efx_fe_cp_materialpeligro });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_nombre', value: itemDatos.name });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_cantidad', value: fieldItem.cantidad });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_valor_mercancia', value: fieldItem.valorMercancia });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso', value: itemDatos.custitem_efx_fe_cp_pesokg });

                        } else {
                            //============Se llenan los campos como vacios==========================================
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_cod_sat', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_nombre', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_cantidad', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_descripcion', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad_hidden', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_cve_mat_peligroso', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_cve_mat_peligroso_hidden', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_embalaje', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad_hidden', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_valor_mercancia', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso', value: '' });

                        }
                    }
                    if (scriptContext.fieldId == 'custpage_lbl_unidad') {
                        let unidad = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad' });
                        if (unidad !== '') {
                            var fieldLookUp = search.lookupFields({ type: 'customrecord_mx_sat_unit_code', id: unidad, columns: ['custrecord_mx_sat_uc_code'] });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad_hidden', value: fieldLookUp.custrecord_mx_sat_uc_code });
                        }

                    }
                    if (scriptContext.fieldId == 'custpage_lbl_moneda') {
                        let idMoneda = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_moneda' });
                        console.log('moneda: ', idMoneda);
                        if (idMoneda !== '') {
                            var fieldLookUp = search.lookupFields({ type: 'currency', id: idMoneda, columns: ['name'] });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_moneda_hidden', value: fieldLookUp.name });
                        }
                    }
                    if (scriptContext.fieldId == 'custpage_lbl_fraccion_arancelaria') {
                        let idFraccion = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_fraccion_arancelaria' });
                        console.log('Fraccion arancelaria: ', idFraccion);
                        if (idFraccion !== '') {
                            var fieldLookUp = search.lookupFields({ type: 'customrecord_efx_fe_arancelaria_2', id: idFraccion, columns: ['name'] });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_fraccion_arancelaria_nombre', value: fieldLookUp.name });
                        }
                    }
                    if (scriptContext.fieldId == 'custpage_lbl_embalaje') {
                        let idEmbalaje = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_embalaje' });
                        console.log('Embalaje: ', idEmbalaje);
                        if (idEmbalaje !== '') {
                            var fieldLookUp = search.lookupFields({ type: 'customrecord_efx_fe_cp_tipoembalaje', id: idEmbalaje, columns: ['name'] });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_embalaje_hidden', value: fieldLookUp.name });
                        }
                    }


                }
                if (scriptContext.sublistId == 'custpage_datos_escalas') {
                    if (scriptContext.fieldId == 'custpage_lbl_tipo_proveedor_escalas') {
                        let proveedor = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_tipo_proveedor_escalas' });
                        let nombreProveedor = proveedor !== '' ? search.lookupFields({
                            type: search.Type.VENDOR,
                            id: proveedor,
                            columns: ['companyname', 'custentity_mx_rfc']
                        }) : '';
                        let busquedaProv = proveedor != '' ? busquedaProveedores(proveedor) : {}
                        console.log('busquedaProv: ', typeof busquedaProv.hasOwnProperty);
                        if (Object.keys(busquedaProv).length !== 0) {
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_nombre_escalas', value: nombreProveedor.companyname || '' });
                            // objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_rfc_escalas', value: busquedaProv.rfc });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_rfc_escalas', value: nombreProveedor.custentity_mx_rfc || '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_calle_escalas', value: busquedaProv.calle });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_ext_escalas', value: busquedaProv.ext });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_int_escalas', value: busquedaProv.int });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_codpostal_escalas', value: busquedaProv.cp });
                        } else {
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_nombre_escalas', value: nombreProveedor.companyname || '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_rfc_escalas', value: nombreProveedor.custentity_mx_rfc || '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_calle_escalas', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_ext_escalas', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_int_escalas', value: '' });
                            objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_codpostal_escalas', value: '' });
                        }


                    }
                    //if (scriptContext.fieldId == 'custpage_lbl_colonia_escalas') {
                    //  let colonia = objRecord.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_colonia_escalas' });
                    //var cp = search.lookupFields({
                    //  type: 'customrecord_efx_fe_sat_colonia',
                    //id: colonia,
                    //columns: ['custrecord_efx_fe_sc_cp']
                    //});
                    //console.log('cp: ', cp);
                    //objRecord.setCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_codpostal_escalas', value: cp.custrecord_efx_fe_sc_cp_2 || '' });
                    //}
                }
            } catch (e) {
                console.error('Field Change: ', e);
            }

        }

        /**
         * 
         * @param {*} proveedor 
         * @summary Funcion encargada de la búsqueda de proveedores y seteo de valores
         */
        function busquedaProveedores(proveedor) {
            try {
                console.log('proveedor: ', proveedor)
                var vendorSearchObj = search.create({
                    type: search.Type.VENDOR,
                    filters:
                        [
                            ["address.isdefaultshipping", "is", "T"],
                            "AND",
                            ["address.isdefaultbilling", "is", "T"],
                            "AND",
                            ["internalid", "anyof", proveedor],
                            "AND",
                            ["isdefaultshipping", "is", "T"],
                            "AND",
                            ["isdefaultbilling", "is", "T"]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "altname", label: "Nombre" }),
                            search.createColumn({ name: "custentity_mx_rfc", label: "RFC" }),
                            search.createColumn({ name: "address", label: "Dirección" }),
                            search.createColumn({ name: "country", join: "Address", label: "País" }),
                            search.createColumn({ name: "zipcode", join: "Address", label: "Código postal" }),
                            search.createColumn({ name: "state", join: "Address", label: "Estado/provincia" }),
                            search.createColumn({ name: "custrecord_streetname", join: "Address", label: "Calle" }),
                            search.createColumn({ name: "custrecord_streetnum", join: "Address", label: "Número de Calle (Número Exterior)" }),
                            search.createColumn({ name: "custrecord_unit", join: "Address", label: "Apartamento (Número Interior)" }),
                            search.createColumn({ name: "custrecord_village", join: "Address", label: "Municipio" }),
                            search.createColumn({ name: "custrecord_locality", join: "Address", label: "Locality" }),
                            search.createColumn({ name: "custrecord_colonia", join: "Address", label: "Colonia" })

                        ]
                });

                let vendor = {};
                // var searchResultCount = customrecord_tkio_cartaporte_rpSearchObj.runPaged().count;
                // console.log("customrecord_tkio_cartaporte_rpSearchObj result count",searchResultCount);
                vendorSearchObj.run().each(function (result) {
                    vendor = {
                        nombre: '',
                        rfc: '',
                        calle: '',
                        ext: '',
                        int: '',
                        pais: '',
                        estado: '',
                        municipio: '',
                        cp: '',
                        localidad: '',
                        colonia: ''
                    }
                    vendor.nombre = result.getValue({ name: "altname" }) || '';
                    vendor.rfc = result.getValue({ name: "custentity_mx_rfc" }) || '';
                    vendor.pais = result.getValue({ name: "country", join: "Address" }) || '';
                    vendor.cp = result.getValue({ name: "zipcode", join: "Address" }) || '';
                    vendor.estado = result.getValue({ name: "state", join: "Address" }) || '';
                    vendor.calle = result.getValue({ name: "custrecord_streetname", join: "Address" }) || '';
                    vendor.ext = result.getValue({ name: "custrecord_streetnum", join: "Address" }) || '';
                    vendor.int = result.getValue({ name: "custrecord_unit", join: "Address" }) || '';
                    vendor.municipio = result.getValue({ name: "custrecord_village", join: "Address" }) || '';
                    vendor.localidad = result.getValue({ name: "custrecord_locality", join: "Address" }) || '';
                    vendor.colonia = result.getValue({ name: "custrecord_colonia", join: "Address" }) || '';

                    return true;
                });
                console.log(JSON.stringify(vendor));
                return vendor;
            } catch (e) {
                console.error('busquedaProveedores: ', e);
                return {}
            }

        }


        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        var totalpBruto = 0;
        var totalpNeto = 0;
        var totalMercancias = 0;
        function validateLine(scriptContext) {
            try {
                console.log({ title: 'Lista de materiales iniciales: ', details: materiales });
                var sublistName = scriptContext.sublistId;
                let flagGlobal;
                let flagDatosUbicaciones;
                let claveUnidadPeso = '';


                var currentForm = currentRecord.get();
                if (sublistName === 'custpage_datos_escalas') {
                    //=======================================Obtención de datos de sublista escalas=================================
                    let tipoUbicacion = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_tipo_ubicacion_escalas' });
                    let rfc = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_rfc_escalas' });
                    let nombre = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_nombre_escalas' });
                    let calle = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_calle_escalas' });
                    let exterior = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_ext_escalas' });
                    let interior = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_int_escalas' });
                    let pais = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_pais_escalas' });
                    let estado = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_estado_escalas' });
                    let municipio = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_municipio_escalas' });
                    let localidad = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_localidad_escalas' });
                    let colonia = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_colonia_escalas' });
                    let cp = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_escalas', fieldId: 'custpage_lbl_codpostal_escalas' });
                    let currIndex = currentForm.getCurrentSublistIndex({ sublistId: 'custpage_datos_escalas' });
                    console.log('tipo de ubicacion: ', tipoUbicacion, ' nombre: ', nombre, ' pais: ', pais);
                    if (tipoUbicacion != '' && nombre != '' && pais != '') {
                        var typeUbicacion = search.lookupFields({ type: 'customlist_tkio_tipubibacnregistro_esc', id: tipoUbicacion, columns: ['name'] });
                        let nombreUbicacion = typeUbicacion.name;
                        var nombrePais = search.lookupFields({ type: 'customrecord_efx_fe_sat_pais', id: pais, columns: ['custrecord_efx_fe_sp_cod_sat'] });
                        var nomPais = nombrePais.custrecord_efx_fe_sp_cod_sat;
                        let tipoubicacion = { id: tipoUbicacion, nombre: nombreUbicacion }

                        let objDireccion = {
                            calle: calle,
                            exterior: exterior,
                            interior: interior,
                            pais: nomPais || '',
                            estado: estado,
                            municipio: municipio,
                            localidad: localidad,
                            colonia: colonia,
                            cp: cp
                        }

                        objUbicaciones = {
                            index: currIndex,
                            tipoubicacion: tipoubicacion,
                            rfc: rfc,
                            nombre: nombre,
                            direccion: objDireccion

                        }

                        if (ubicaciones.length == 0 || ubicaciones[currIndex] == undefined) {
                            ubicaciones.push(objUbicaciones);
                        }
                        else {
                            ubicaciones[currIndex].index = currIndex;
                            ubicaciones[currIndex].tipoubicacion.id = tipoUbicacion;
                            ubicaciones[currIndex].tipoubicacion.nombre = nombreUbicacion;
                            ubicaciones[currIndex].nombre = nombre;
                            ubicaciones[currIndex].rfc = rfc;
                            ubicaciones[currIndex].direccion.calle = calle;
                            ubicaciones[currIndex].direccion.exterior = exterior;
                            ubicaciones[currIndex].direccion.interior = interior;
                            ubicaciones[currIndex].direccion.pais = nombrePais.custrecord_efx_fe_sp_cod_sat;
                            ubicaciones[currIndex].direccion.estado = estado;
                            ubicaciones[currIndex].direccion.municipio = municipio;
                            ubicaciones[currIndex].direccion.localidad = localidad;
                            ubicaciones[currIndex].direccion.colonia = colonia;

                        }

                        console.log('array Ubicaciones: ' + JSON.stringify(ubicaciones));
                        flagDatosUbicaciones = true;


                    } else {
                        var mensajeError = message.create({
                            type: message.Type.ERROR,
                            title: "LLENADO DE FORMULARIO INCOMPLETO",
                            message: "No se lleno correctamente la lista, verifique que los campos Tipo de ubicación, nombre y país han sido introducidos."
                        });
                        mensajeError.show({ duration: 4500 });
                        flagDatosUbicaciones = false;
                    }
                    if (flagDatosUbicaciones) {
                        flagGlobal = true;
                    }
                    else {
                        flagGlobal = false;
                    }
                }
                else if (sublistName === 'custpage_datos_mercancia') {
                    //=====================================Obtención de datos============================================
                    let linePibote = Number(currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes' }));
                    console.log({ title: 'linePibote', details: linePibote });
                    let bien = items.find(itemPibote => itemPibote.idLine === linePibote).id
                    console.log({ title: 'bien', details: bien });
                    let nombreBien = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_nombre' });
                    let idLine = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_line_id' })
                    let claveSatbien = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_cod_sat' });
                    console.log('claveSatBien: ', claveSatbien);
                    let cveMaterialId = '';
                    let cveMaterialNombre = '';
                    let flagMaterialPeligroso = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_mat_peligroso' });
                    let embalajeNombre = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_embalaje_hidden' });
                    let embalajeId = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_embalaje' });
                    let descripcion = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_descripcion' });
                    let unidadId = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad' });

                    let unidadNombre = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_unidad_hidden' });

                    let valorMercancia = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_valor_mercancia' });
                    let flagMaterial = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_flag_mat_peligroso' });
                    let cantidad = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_cantidad' });
                    let idCurrency = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_moneda' });
                    let nombreCurrency = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_moneda_hidden' });
                    let idSatBien = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_sat' });
                    let nombreSatBien = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_bienes_nombre_sat' });
                    let arancelariaId = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_fraccion_arancelaria' });
                    let arancelariaNombre = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_fraccion_arancelaria' });
                    let factura = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_factura' });
                    let pedimento = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_pedimento' });
                    let transporteInt = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_transp_int' });
                    let entrada_salida = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_ent_sal_merc' });
                    let paisOrigenDestino = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_pais_orig_dest' });
                    let total_distancia = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_total_distancia' });
                    let currIndexBienes = currentForm.getCurrentSublistIndex({ sublistId: 'custpage_datos_mercancia' });

                    let pesoNeto = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso_neto' });
                    let pesoBruto = currentForm.getCurrentSublistValue({ sublistId: 'custpage_datos_mercancia', fieldId: 'custpage_lbl_peso_bruto' });
                    console.log('pesoBruto: ', pesoBruto);



                    var nomPais = '';
                    if (paisOrigenDestino !== '') {
                        var nombrePais = search.lookupFields({ type: 'customrecord_efx_fe_sat_pais', id: paisOrigenDestino, columns: ['custrecord_efx_fe_sp_cod_sat'] });
                        var nomPais = nombrePais.custrecord_efx_fe_sp_cod_sat;
                    }
                    console.log('idSATBien: ', nombreBien);
                    // if (nombreBien != '') 
                    if (idSatBien != '') {
                        console.log({ title: 'flagMaterialPeligroso', details: flagMaterialPeligroso });
                        if (flagMaterialPeligroso === 'si') {
                            // console.log({ title: 'bien', details: bien });
                            // var idItem = 
                            var itemDatos = search.lookupFields({ type: search.Type.ITEM, id: bien, columns: ['custitem_efx_fe_cp_cvematpeligro', 'custitem_efx_fe_cp_materialpeligro'] });
                            // var itemDatos = search.lookupFields({ type: search.Type.ITEM, id: id, columns: ['custitem_efx_fe_cp_cvematpeligro', 'custitem_efx_fe_cp_materialpeligro'] });
                            if (itemDatos.custitem_efx_fe_cp_cvematpeligro.length != 0) {
                                cveMaterialId = itemDatos.custitem_efx_fe_cp_cvematpeligro[0].value;
                                cveMaterialNombre = itemDatos.custitem_efx_fe_cp_cvematpeligro[0].text;
                            }
                        }
                        console.log({ title: 'bien', details: bien });
                        var claveSat = search.lookupFields({ type: search.Type.ITEM, id: bien, columns: ['custitem_efx_fe_cp_cvematpeligro', 'custitem_efx_fe_cp_materialpeligro'] });
                        //==========================================LLENADO DE OBJETOS====================================
                        console.log('claveSatbien2: ', claveSatbien);
                        let objMaterial = { id: idSatBien, nombre: claveSatbien }
                        let objClvmaterialpeligroso = { id: cveMaterialId, nombre: cveMaterialNombre }
                        let objEmbalaje = { id: embalajeId, nombre: embalajeNombre }
                        let objUnidad = { id: unidadId, nombre: unidadNombre }
                        jsonCurrency = { id: idCurrency, nombre: nombreCurrency };
                        let objAranceles = { id: arancelariaId, nombre: arancelariaNombre }



                        objMercancia = {
                            idLine: idLine,
                            index: currIndexBienes,
                            item: {
                                value: bien,
                                text: nombreBien
                            },
                            material: objMaterial,
                            cantidad: cantidad,
                            pesoneto: pesoNeto,
                            pesobruto: pesoBruto,
                            clvmaterialpeligroso: objClvmaterialpeligroso,
                            descripcion: descripcion,
                            embalaje: objEmbalaje,
                            unidad: objUnidad,
                            valormercancia: valorMercancia,
                            materialpeligroso: flagMaterial,
                            moneda: jsonCurrency,
                            fraccionarancelaria: objAranceles,
                            factura: factura,
                            pedimento: pedimento,
                            transporteinternacional: transporteInt,
                            entradasalidamerc: entrada_salida,
                            paisorigen: nomPais,
                            totaldistancia: total_distancia
                        }

                        if (materiales.length == 0 || materiales[currIndexBienes] == undefined) {
                            // let buscar = (element) => element.material.id == idSatBien;
                            // let indice = materiales.findIndex(buscar);
                            // let indice = materiales.find(linePib => linePib.idLine.value === objMercancia.item.value) || null;
                            let indice = materiales.find(linePib => linePib.idLine === objMercancia.idLine) || null;
                            if (!indice) {
                                materiales.push(objMercancia);
                                flagGlobal = true;
                                // totalpBruto += Number(pesoBruto);
                                // totalpNeto += Number(pesoNeto);
                                // totalMercancias++;

                                // objtotalMercancias = {
                                //     totalMercancias:totalMercancias,
                                //     totalpBruto: totalpBruto,
                                //     totalpNeto: totalpNeto,
                                //     claveUnidadPeso: unidadNombre
                                // }

                            } else {

                                let mensajeError = message.create({
                                    type: message.Type.ERROR,
                                    title: "Línea ingresada con anterioridad.",
                                    message: "Verifique que la línea introducida no este en la lista ingresada. "
                                    // title: "Artículo ingresado con anterioridad.",
                                    // message: "Verifique que el artículo introducido no este en la lista ingresada. "
                                });
                                mensajeError.show({ duration: 3500 });
                                flagGlobal = false;
                            }

                        }
                        else {
                            materiales[currIndexBienes].index = currIndexBienes;
                            materiales[currIndexBienes].material.id = idSatBien;
                            materiales[currIndexBienes].material.nombre = claveSatbien;
                            materiales[currIndexBienes].clvmaterialpeligroso.id = cveMaterialId;
                            materiales[currIndexBienes].clvmaterialpeligroso.nombre = cveMaterialNombre;
                            materiales[currIndexBienes].cantidad = cantidad;
                            materiales[currIndexBienes].embalaje.id = embalajeId;
                            materiales[currIndexBienes].embalaje.nombre = embalajeNombre;
                            materiales[currIndexBienes].unidad.id = unidadId;
                            materiales[currIndexBienes].unidad.nombre = unidadNombre;
                            materiales[currIndexBienes].descripcion = descripcion;
                            materiales[currIndexBienes].valormercancia = valorMercancia;
                            materiales[currIndexBienes].materialpeligroso = flagMaterial;
                            materiales[currIndexBienes].moneda.id = idCurrency;
                            materiales[currIndexBienes].moneda.nombre = nombreCurrency;
                            materiales[currIndexBienes].fraccionarancelaria.id = arancelariaId;
                            materiales[currIndexBienes].fraccionarancelaria.nombre = arancelariaNombre;
                            materiales[currIndexBienes].factura = factura;
                            materiales[currIndexBienes].pedimento = pedimento;
                            materiales[currIndexBienes].transporteinternacional = transporteInt;
                            materiales[currIndexBienes].entradasalidamerc = entrada_salida;
                            materiales[currIndexBienes].paisorigen = nomPais;
                            materiales[currIndexBienes].totaldistancia = total_distancia;

                            materiales[currIndexBienes].pesobruto = pesoBruto;
                            materiales[currIndexBienes].pesoneto = pesoNeto;
                            // objtotalMercancias = {
                            //     totalMercancias:cantidad,
                            //     totalpBruto: pesoBruto,
                            //     totalpNeto: pesoNeto,
                            //     claveUnidadPeso: unidadNombre
                            // }


                            flagGlobal = true;
                        }
                        // flagGlobal = true;
                    } else {
                        let mensajeError = message.create({
                            type: message.Type.ERROR,
                            title: "Artículo sin clave SAT",
                            message: "Verifique que el artículo introducido contenga una clave SAT"
                        });
                        mensajeError.show({ duration: 3500 });
                        flagGlobal = false;
                    }
                    // if(flagGlobal){
                    //     objtotalMercancias = {
                    //         totalMercancias:totalMercancias,
                    //         totalpBruto: totalpBruto,
                    //         totalpNeto: totalpNeto,
                    //         claveUnidadPeso: unidadNombre
                    //     }
                    // }

                }

                console.log(JSON.stringify(materiales));
                console.log({ title: 'Lista de materiales final:', details: materiales });
                // console.log(JSON.stringify(objtotalMercancias));
                return flagGlobal;
            } catch (e) {
                console.error('Validate Line: ', e);
            }

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {
            var currentForm = scriptContext.currentRecord;
            var sublistName = scriptContext.sublistId;

            if (sublistName == 'custpage_datos_escalas') {
                var currIndex = currentForm.getCurrentSublistIndex({
                    sublistId: 'custpage_datos_escalas'
                });
                console.log('currIndex: ' + currIndex);
                ubicaciones = ubicaciones.filter((item) => item.index !== currIndex);
                console.log('array Ubicaciones: ' + JSON.stringify(ubicaciones))

                return true;

            }
            else if (sublistName == 'custpage_datos_mercancia') {

                var currIndex = currentForm.getCurrentSublistIndex({
                    sublistId: 'custpage_datos_mercancia'
                });
                materiales = materiales.filter((item) => item.index !== currIndex);
                console.log('array Ubicaciones: ' + JSON.stringify(materiales))

                return true;

            }
        }


        /**
        * Función que permitirá traer el valor de un parametro dentro de la url
        * @param String name
        * @return String
        */
        function getParameterByName(name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }

        /**
         * @summary Función encargada de generar el documento PDF.
         */
        function generar() {
            try {
                objtotalMercancias = {
                    // totalMercancias:0.0,
                    totalMercancias: materiales.length,
                    totalpBruto: 0.0,
                    totalpNeto: 0.0,
                    claveUnidadPeso: 'kgs'
                }
                if (ubicaciones.length != 0 && materiales.length != 0) {
                    materiales.forEach(item => {
                        objtotalMercancias.totalpBruto += parseFloat(item.pesobruto);
                        objtotalMercancias.totalpNeto += parseFloat(item.pesoneto);
                        // objtotalMercancias.totalMercancias += parseFloat(item.cantidad);

                    })
                    console.log('objtotalMercancias: ', JSON.stringify(objtotalMercancias));
                    objGlobal = {
                        cabecera: jsonCliente,
                        material: materiales,
                        escalas: ubicaciones,
                        totalmercancias: objtotalMercancias
                    }

                    console.log('ObjGlobal: ', JSON.stringify(objGlobal));
                    var headers = {
                        "Content-Type": "application/json"
                    };

                    var out = url.resolveScript({
                        scriptId: 'customscript_tkio_servicio_cartaporte_sl',
                        deploymentId: 'customdeploy_tkio_servicio_cartaporte_sl',
                        returnExternalUrl: true
                    });
                    console.log('out: ' + out);

                    var response = https.post({
                        url: out,
                        body: JSON.stringify(objGlobal),
                        headers: headers
                    });


                    var respuesta = JSON.parse(response.body);
                    console.log('status' + respuesta.mensaje);
                    if (respuesta.status == 200) {

                        var urls = url.resolveScript({
                            scriptId: "customscript_tkio_cartaporte_complemento",
                            deploymentId: "customdeploy_tkio_cartaporte_complemento",
                            params: { idOrdenCompra: respuesta.mensaje }
                        })
                        console.log('urls: ' + urls + respuesta.mensaje);
                        window.open(urls, '_blank')
                    } else {
                        let mensajeError = message.create({
                            type: message.Type.ERROR,
                            title: "Error en la generación del PDF",
                            message: "Consulte a su administrador."
                        });
                        mensajeError.show({ duration: 3500 });
                    }
                } else {
                    let mensajeError = message.create({
                        type: message.Type.ERROR,
                        title: "LLENADO DE FORMULARIO INCOMPLETO",
                        message: "Asegurese de llenar las dos sublistas en pantalla."
                    });
                    mensajeError.show({ duration: 3500 });
                }
            } catch (e) {
                console.error(e);
            }

        }

        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged,
            validateLine: validateLine,
            validateDelete: validateDelete,
            generar: generar

        };

    });
