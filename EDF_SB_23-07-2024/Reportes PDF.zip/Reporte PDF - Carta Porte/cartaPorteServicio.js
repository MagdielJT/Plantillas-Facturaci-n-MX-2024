/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/record', './Controller/errores_personalizados.js', 'N/https', './Controller/moment.min.js', 'N/format'],
   /**
* @param{error} error
* @param{record} record
*/
   (record, _error, https, moment, format) => {
      /**
       * Defines the Suitelet script trigger point.
       * @param {Object} scriptContext
       * @param {ServerRequest} scriptContext.request - Incoming request
       * @param {ServerResponse} scriptContext.response - Suitelet response
       * @since 2015.2
       */

      var RES
      const onRequest = (scriptContext) => {
         let seccion = ''
         try {
            // Cargar datos de Suitelet
            seccion = 'Datos Suitelet'; {
               RES = scriptContext.response
               var REQ = scriptContext.request
               var PARAM = JSON.parse(REQ.body)
               log.debug({ title: 'PARAM', details: PARAM });

               // Error No existen datos en el post: POST_METHOD_NOT_FOUND
               if (REQ.method !== https.Method.POST)
                  throw new Error('POST_METHOD_NOT_FOUND')
            }
            // var parametros = PARAM.totalmercancias.totalpNeto;
            log.debug({title: 'PARAM.totalmercancias.totalpNeto', details: PARAM.totalmercancias.totalMercancias});
            log.debug({title: 'PARAM.totalmercancias.totalpNeto', details: PARAM.totalmercancias.totalpBruto});
            // Obtener objeto por POST
            seccion = 'Objetos por POST'; {
               // Error objeto vacio : MISSING_OBJECT
            }
            // Validar datos
            seccion = 'Validacion de datos'; {
               // Error objeto llaves claves vacios / valores necesarios vacios: VALIDATE_DATA   
               var cartaPorteC = PARAM.cabecera
               let validacionDeCabecera = ((cartaPorteC.hasOwnProperty("subsidiaria") && cartaPorteC.subsidiaria.id !== "") &&
                  (cartaPorteC.hasOwnProperty("rfc") && cartaPorteC.rfc !== "") &&
                  (cartaPorteC.hasOwnProperty("proveedor") && cartaPorteC.proveedor.id !== "") &&
                  (cartaPorteC.hasOwnProperty("ordencompra") && cartaPorteC.ordencompra.id !== "") &&
                  (cartaPorteC.hasOwnProperty("numeropedido") && cartaPorteC.numeropedido !== "") &&
                  (cartaPorteC.hasOwnProperty("estadoaprobacion") && cartaPorteC.estadoaprobacion.id !== ""))

               if (!validacionDeCabecera)
                  throw 'VALIDATE_DATA';


               var idEscales = [... new Set(PARAM.escalas.map(cadaEscala => {
                  let validacionEscala = ((cadaEscala.hasOwnProperty("tipoubicacion") && cadaEscala.tipoubicacion.id !== "") &&
                     (cadaEscala.hasOwnProperty("rfc")) &&
                     (cadaEscala.hasOwnProperty("nombre") && cadaEscala.nombre !== "") &&
                     // (cadaEscala.hasOwnProperty("direccion") && (cadaEscala.direccion.calle !== "" && cadaEscala.direccion.pais !== "" && cadaEscala.direccion.estado !== "")))
                     (cadaEscala.hasOwnProperty("direccion")))

                  if (!validacionEscala)
                     throw 'VALIDATE_DATA';

                  let guardandoEscalas = record.create({
                     type: "customrecord_tkio_escalas_rp",
                     isDynamic: true
                  })
                  guardandoEscalas.setValue({
                     fieldId: 'custrecord_tkio_tipoubicacion_rp',
                     value: Number(cadaEscala.tipoubicacion.id)
                  })
                  guardandoEscalas.setValue({
                     fieldId: 'custrecord_tkio_rfc_rp',
                     value: cadaEscala.rfc
                  })
                  guardandoEscalas.setValue({
                     fieldId: 'custrecord_tkio_nombre_rp',
                     value: cadaEscala.nombre
                  })
                  log.debug("Direeciion", cadaEscala.direccion)
                  log.debug("Direeciion interior", JSON.stringify(cadaEscala.direccion.interior));
                  log.debug("Direeciion exterior", JSON.stringify(cadaEscala.direccion.exterior));
                  
                  guardandoEscalas.setValue({
                     fieldId: 'custrecord_tkio_calle_rp',
                     value: JSON.stringify(cadaEscala.direccion)
                  })
                  try {
                     return guardandoEscalas.save({
                        enableSourcing: true,
                        ignoreMandatoryFields: true
                     })
                  } catch (e) {
                     log.debug("Error", e)
                     throw 'UNSAVE_DATA';
                  }
               }))]
               log.debug(`🚀 ~ file: cartaPorteServicio.js:192 ~ idEscales ~ idEscales`, idEscales)

               var idMateriales = [... new Set(PARAM.material.map(cadaMaterial => {
                  let validacionMaterial = ((cadaMaterial.hasOwnProperty('material') && cadaMaterial.material.id !== "") &&
                     (cadaMaterial.hasOwnProperty('cantidad') && cadaMaterial.cantidad !== "") &&
                     (cadaMaterial.hasOwnProperty('unidad') ) &&
                     (cadaMaterial.hasOwnProperty('valormercancia') && cadaMaterial.valormercancia !== ""))

                  if (!validacionMaterial)
                     throw 'VALIDATE_DATA';

                  let guardandoMateriales = record.create({
                     type: "customrecord_tkio_bienestrasportados_rp",
                     isDynamic: true
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_bienes_rp',
                     value: cadaMaterial.material.id
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_descripcion_rp',
                     value: cadaMaterial.descripcion
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_cantidad_rp',
                     value: cadaMaterial.cantidad
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_unidad_rp',
                     value: cadaMaterial.unidad.id
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_peso_rp',
                     value: cadaMaterial.peso
                  })
                  log.debug({title: 'cadaMaterial.pedimento', details: cadaMaterial.pedimento});
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_pedimento_rp',
                     value: cadaMaterial.pedimento
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_clvmaterial_rp',
                     value: Number(cadaMaterial.clvmaterialpeligroso.id) || ''
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_embalaje_rp',
                     value: Number(cadaMaterial.embalaje.id) || ''
                  })
                  if (cadaMaterial.fraccionarancelaria.id !== '') {
                     guardandoMateriales.setValue({
                        fieldId: 'custrecord_tkio_fraccionarancelaria_rp',
                        value: Number(cadaMaterial.fraccionarancelaria.id) || ''
                     })
                  }
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_factura_rp',
                     value: cadaMaterial.factura
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_valormercancia_rp',
                     value: cadaMaterial.valormercancia
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_moneda_rp',
                     value: Number(cadaMaterial.moneda.id) || ''
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_transportinternacnl_rp',
                     value: cadaMaterial.transporteinternacional
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_entradasalidamerc_rp',
                     value: cadaMaterial.entradasalidamerc
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_paisorigendest_rp',
                     value: cadaMaterial.paisorigen
                  })
                  log.debug("Distancia: ", cadaMaterial.totaldistancia)
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_totaldistacia_rp',
                     value: parseFloat(cadaMaterial.totaldistancia) || 0.0
                  })
                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_materialpeligroso_rp',
                     value: cadaMaterial.materialpeligros == "false" ? false :
                        cadaMaterial.materialpeligros == "true" ? true : false
                  })

                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_peso_bruto_rp',
                     value: parseFloat(cadaMaterial.pesobruto)
                  })

                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_peso_neto_rp',
                     value: parseFloat(cadaMaterial.pesoneto)
                  })

                  guardandoMateriales.setValue({
                     fieldId: 'custrecord_tkio_clavesat_rp',
                     value: cadaMaterial.material.nombre
                  })

                  try {
                     return guardandoMateriales.save({
                        enableSourcing: true,
                        ignoreMandatoryFields: true
                     })
                  } catch (e) {
                     throw 'UNSAVE_DATA';
                  }

               }))]
               log.debug(`🚀 ~ file: cartaPorteServicio.js:215 ~ idMateriales ~ idMateriales`, idMateriales)

            }
            log.debug("cartaPorteC.fechacompra: ", cartaPorteC.fechacompra)
            log.debug("Formato fecha compra enviada moment", moment(cartaPorteC.fechacompra).locale('es-mx').format('YYYY/MM/DD'))

            // Guardar Informacion
            seccion = 'Guardar información en registro principal'; {
               // Error al guardar datos: UNSAVE_DATA
               let guardandoCartaPorte = record.create({
                  type: "customrecord_tkio_cartaporte_rp",
                  isDynamic: true
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_escalas_cp',
                  value: idEscales
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_materiales_cp',
                  value: idMateriales
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_idordendecomprar_cp',
                  value: cartaPorteC.ordencompra.id
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_fechacompra_cp',
                  value: format.parse({
                     value: moment(cartaPorteC.fechacompra).locale('es-mx').format('YYYY/MM/DD'),
                     type: format.Type.DATE
                  })
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_numeropedido_cp',
                  value: cartaPorteC.numeropedido
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_proveedor_cp',
                  value: cartaPorteC.proveedor.id
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_clientecompra_cp',
                  value: cartaPorteC.subsidiaria.id || ''
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_fechaprevistaentrega_cp',
                  value: format.parse({
                     value: moment(cartaPorteC.fechacompra).locale('es-mx').format('YYYY/MM/DD'),
                     type: format.Type.DATE
                  })
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_estadoaprobacion_cp',
                  value: cartaPorteC.estadoaprobacion.id
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_subsidiaria_cp',
                  value: cartaPorteC.subsidiaria.id
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_rfccliente_cp',
                  value: cartaPorteC.rfc
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_razonsocial_cp',
                  value: cartaPorteC.razonsocial
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_direccioncompuesta_cp',
                  value: cartaPorteC.direccion
               })
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_otrosdatos_cp',
                  value: cartaPorteC.extras
               })
               //==========Datos para la parte de total de mercancias==================
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_totalpesoneto',
                  value: parseFloat(PARAM.totalmercancias.totalpNeto)
               });
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_totalpesobruto',
                  value: parseFloat(PARAM.totalmercancias.totalpBruto)
               });
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_totaldemercancias',
                  value: parseFloat(PARAM.totalmercancias.totalMercancias)
               });
               guardandoCartaPorte.setValue({
                  fieldId: 'custrecord_tkio_claveunidadpeso',
                  value: PARAM.totalmercancias.claveUnidadPeso
               })

               

               try {
                  var idComplementoCartaPorte = guardandoCartaPorte.save({
                     enableSourcing: true,
                     ignoreMandatoryFields: true
                  })
               } catch (e) {
                  throw 'UNSAVE_DATA';
               }

               log.debug("id", idComplementoCartaPorte)
            }

            // Retornar respuesta
            seccion = 'Retorno de respuesta'; {
               envio({ status: 200, mensaje: idComplementoCartaPorte })
            }
         } catch (e) {
            log.debug(`❌ ~ onRequest ~ ${seccion}`, e)
            /** 
             * Controlador de errores para suitelet
             */
            switch (e) {
               case 500:
                  /** Errores de servidor */
                  throw _error.error500
                  break;
               case 400:
                  /** No se encontro  */
                  throw _error.error400
                  break;
               case 'POST_METHOD_NOT_FOUND':
                  throw _error.POST_METHOD_NOT_FOUND
                  break;
               case 'MISSING_OBJECT':
                  throw _error.MISSING_OBJECT
                  break;
               case 'VALIDATE_DATA':
                  throw _error.VALIDATE_DATA
                  break;
               case 'UNSAVE_DATA':
                  throw _error.UNSAVE_DATA
                  break;
               default:
                  throw _error.errorUnknown
                  break;
            }
         }
      }
      const envio = (datos) => {
         try {
            RES.write({ output: JSON.stringify(datos) })
            RES.setHeader({
               name: 'Content-Type',
               value: 'application/json'
            });
         } catch (e) {
            log.debug("❌ Error la intentar responder ", e)
         }
      }

      return { onRequest }

   });