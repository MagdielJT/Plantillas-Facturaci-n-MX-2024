/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 */
define(['N/currentRecord','N/url'], function(currentRecord, url) {
    function cartaComplementoSL(){
       try {
        var records = currentRecord.get();
        console.log("registro: ",records);
        var id = records.getValue('id');
        console.log("Id registro: ",id);

        var scriptUrl = url.resolveScript({
            scriptId: 'customscript_tkio_repote_cartaporte_sl',
            deploymentId: 'customdeploy_tkio_reporte_cartaporte_sl',
            params:{
                ordenDeCompra: id
            }
        });
        if(id){
            window.open(scriptUrl, '_blank');
        }
       } catch (e) {
        log.debug(e.name,e.message)
       }
    }

    function pageInit(context) {
        // custpage_lblclientenombre
        // var currentForm = currentRecord.get();
        // console.log('currentForm: '+currentForm);    
        // currentForm.setValue({fieldId: 'custpage_lblclientenombre', value: 'hola mundo'});

        
    }

    return {
        pageInit: pageInit,
        cartaComplementoSL:cartaComplementoSL
    }
});
