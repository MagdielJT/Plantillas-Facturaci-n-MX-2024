/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/render', 'N/runtime', './Controller/plantillaPDF.js','N/error','./Controller/datos_registro.js'],
/**
 * @param{render} render
 * @param{runtime} runtime
 */
    (render, runtime, controlador,error, busquedas) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let seccion = ''
            try {
                seccion = 'Recopilación de informacion';{
                    var _REQ = scriptContext.request
                    var _RES = scriptContext.response
                    var _PARAMS = _REQ.parameters
                    
                    if( !_PARAMS.hasOwnProperty("idOrdenCompra") )
                        throw Error("El parametro idOrdenCompra no existe")
                
                    var idOrdenCompra = _PARAMS.idOrdenCompra
                }
                seccion = 'Busquedas guardadas';{
                    log.debug("idOrdenCompra", idOrdenCompra )
                    var complemento_carta_porte = busquedas.cartaporte(idOrdenCompra)
                    log.debug("complemento_carta_porte;", complemento_carta_porte)
                    let imagen = runtime.getCurrentScript().getParameter({name:'custscript_tkio_logo_pdf'})
                    log.debug("imagen direccion: ", imagen)
                    complemento_carta_porte.imagen = imagen
                }
                seccion = 'Crear pdf';{
                    var plantilla = controlador.plantillaPDF( complemento_carta_porte )
                }
                seccion = 'Mostrar pdf';{
                    _RES.renderPdf(plantilla);
                }
            } catch (e) {
                log.debug(`❌ Error onRequest: ${seccion} `, [e.name, e.message])
                let mensajeError = error.create({
                    message: `Error PDF EDF: No se puede renderizar un PDF - ${e.message}`,
                    name: "ERROR_ONREQUEST_EDF",
                    notifyOff: false
                })
                throw mensajeError
            }
        }

        return {onRequest}

    });
